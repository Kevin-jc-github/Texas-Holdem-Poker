/* team 10 */
/* File name: client */
/* Author: Yuan Wang */
/* Date: 5/21 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netinet/in.h>
#include <netdb.h>
#include "IO.h"
#include "Cards.h"
#include <time.h>

/* #define DEBUG */	/* be very verbose */

void FatalError(const char *Program, const char *ErrorMsg)
{
    fputs(Program, stderr);
    fputs(": ", stderr);
    perror(ErrorMsg);
    fputs(Program, stderr);
    fputs(": Exiting!", stderr);
    exit(20);
} /* end of FatalError */

int main(int argc, char *argv[])
{
    int l, n;
    int chips;
    int SocketFD,	/* socket file descriptor */
	PortNo;		/* port number */
    struct sockaddr_in
	ServerAddress;	/* server address we connect with */
    struct hostent
	*Server;	/* server host */
    char SendBuf[256]; /* message buffer for sending a message */
    char RecvBuf[256];	/* message buffer for receiving a response */
    char cardstr1[10];
    char cardstr12[10];
    char board1[10];
    char board2[10];
    char board3[10];
    char board4[10];
    char  board5[10];
    char potstr[10];
    int arr1[2] = {0};
    int board[5] = {0};
    int pot;

    printf("%s: Starting...\n", argv[0]);
    if (argc < 3)
    {   fprintf(stderr, "Usage: %s hostname port\n", argv[0]);
	exit(10);
    }
#ifdef DEBUG
    printf("%s: Looking up host %s on the network...\n", argv[0], argv[1]);
#endif
    Server = gethostbyname(argv[1]);
    if (Server == NULL)
    {   fprintf(stderr, "%s: no such host named '%s'\n", argv[0], argv[1]);
        exit(10);
    }
    PortNo = atoi(argv[2]);
#ifdef DEBUG
    printf("%s: Using port %d...\n", argv[0], PortNo);
#endif
    if (PortNo <= 2000)
    {   fprintf(stderr, "%s: invalid port number %d, should be greater 2000\n",
		argv[0], PortNo);
        exit(10);
    }
#ifdef DEBUG
    printf("%s: Creating a socket...\n", argv[0]);
#endif
    SocketFD = socket(AF_INET, SOCK_STREAM, 0);
    if (SocketFD < 0)
    {   FatalError(argv[0], "socket creation failed");
    }
#ifdef DEBUG
    printf("%s: Preparing the server address...\n", argv[0]);
#endif
    memset(&ServerAddress, 0, sizeof(ServerAddress));
    ServerAddress.sin_family = AF_INET;
    ServerAddress.sin_port = htons(PortNo);
    memcpy(&ServerAddress.sin_addr.s_addr,
		Server->h_addr_list[0], Server->h_length);
    printf("%s: Connecting to the server...\n", argv[0]);
    if (connect(SocketFD, (struct sockaddr*)&ServerAddress,
		sizeof(ServerAddress)) < 0)
    {   FatalError(argv[0], "connecting to server failed");
    }
        
	/* while the player didn't choose to leave the server, operate */
    do{
	    PrintMenu(); /* print menu */
	    printf("%s: How many chips do you want to buy in(200 -600): ", argv[0]);
	    fgets(SendBuf, sizeof(SendBuf), stdin);
	         /* record the chips */
	           chips = atoi(SendBuf);
	    l = strlen(SendBuf);
	    if (SendBuf[l-1] == '\n')
	    {   SendBuf[--l] = 0;
	    }
	    if (l)
	    {   printf("%s: Sending message '%s'...\n", argv[0], SendBuf);
	    	n = write(SocketFD, SendBuf, l); /* send to the server */
	    	if (n < 0)
	    	{   FatalError(argv[0], "writing to socket failed");
	    	}
#ifdef DEBUG
	    printf("%s: Waiting for response...\n", argv[0]);
#endif
                    /* receive the card from the server */
	    n = read(SocketFD, RecvBuf, sizeof(RecvBuf)-1);
	    if (n < 0) 
	    {   FatalError(argv[0], "reading from socket failed");
	    }
	    RecvBuf[n] = 0;
	    char * token = strtok(RecvBuf, ",");
        int i = 0;
        while( token != NULL ){
            if (i == 0){
                strcpy(cardstr1, token);
            } else if(i==1){
                strcpy(cardstr12, token);
            }
            token = strtok(NULL, ",");
            i++;
        }
        arr1[0] = atoi(cardstr1);
        arr1[1] = atoi(cardstr12);
	    Printhands(arr1,chips);
	}  
	    /* the first round */	
	printf("%s: What would you like to do: Check, Raise, Fold, or Call?,\n"
		"         or type 'exit' to quit this client,\n"
		"         or type 'shutdown' to quit both server and client:\n"
		"Action(Type in the form: Raise, amount/Check/Call/Fold) : ", argv[0]);
	fgets(SendBuf, sizeof(SendBuf), stdin);/* put the action into SendBuff */
	l = strlen(SendBuf); 
	if (SendBuf[l-1] == '\n')
	{   SendBuf[--l] = 0;
	}
	if (l)
	{   printf("%s: Sending message '%s'...\n", argv[0], SendBuf);
	    n = write(SocketFD, SendBuf, l); /* send the action to the server */
	    if (n < 0)
	    {   FatalError(argv[0], "writing to socket failed");
	    }
#ifdef DEBUG
	    printf("%s: Waiting for response...\n", argv[0]);
#endif
	    n = read(SocketFD, RecvBuf, sizeof(RecvBuf)-1);
	    if (n < 0) 
	    {   FatalError(argv[0], "reading from socket failed");
	    }
	    RecvBuf[n] = 0;
	    /* Player recive the flop cards from the server */
	    char * token = strtok(RecvBuf, ",");
         int j = 0;
        while( token != NULL ){
            if (j == 0){
                strcpy(board1, token);
            } 
            else if(j==1){
                strcpy(board2, token);
            }
            else if(j==2){
                strcpy(board3, token);
            }
            else if(j==3){
                strcpy(potstr, token);
            }
            token = strtok(NULL, ",");
            j++;
        }
	    board[0] = atoi(board1);
	    board[1] = atoi(board2);
	    board[2] = atoi(board3);
	    pot = atoi(potstr);
	    PrintBoard(board,pot);
	}
	/* turn round */
	printf("%s: What would you like to do: Check, Raise, Fold, or Call?,\n"
		"         or type 'exit' to quit this client,\n"
		"         or type 'shutdown' to quit both server and client:\n"
		"Action(Type in the form: Raise, amount/Check/Call/Fold) : ", argv[0]);
	fgets(SendBuf, sizeof(SendBuf), stdin);/* put the action into SendBuff */
	l = strlen(SendBuf); 
	if (SendBuf[l-1] == '\n')
	{   SendBuf[--l] = 0;
	}
	if (l)
	{   printf("%s: Sending message '%s'...\n", argv[0], SendBuf);
	    n = write(SocketFD, SendBuf, l); /* send the action to the server */
	    if (n < 0)
	    {   FatalError(argv[0], "writing to socket failed");
	    }
#ifdef DEBUG
	    printf("%s: Waiting for response...\n", argv[0]);
#endif
	    n = read(SocketFD, RecvBuf, sizeof(RecvBuf)-1);
	    if (n < 0) 
	    {   FatalError(argv[0], "reading from socket failed");
	    }
	    RecvBuf[n] = 0;
	    /* Player recive the turn cards from the server */
	    char * token = strtok(RecvBuf, ",");
         int k = 0;
        while( token != NULL ){
            if (k == 0){
                strcpy(board4, token);
            } 
            else if(k==1){
            strcpy(potstr, token);
            }
            token = strtok(NULL, ",");
            k++;
        }
	    board[3] = atoi(board4);
	    pot = atoi(potstr);
	    PrintBoard(board,pot);
        }
	
	/* river round */
	printf("%s: What would you like to do: Check, Raise, Fold, or Call?,\n"
		"         or type 'exit' to quit this client,\n"
		"         or type 'shutdown' to quit both server and client:\n"
		"Action(Type in the form: Raise, amount/Check/Call/Fold) : ", argv[0]);
	fgets(SendBuf, sizeof(SendBuf), stdin);/* put the action into SendBuff */
	l = strlen(SendBuf); 
	if (SendBuf[l-1] == '\n')
	{   SendBuf[--l] = 0;
	}
	if (l)
	{   printf("%s: Sending message '%s'...\n", argv[0], SendBuf);
	    n = write(SocketFD, SendBuf, l); /* send the action to the server */
	    if (n < 0)
	    {   FatalError(argv[0], "writing to socket failed");
	    }
#ifdef DEBUG
	    printf("%s: Waiting for response...\n", argv[0]);
#endif
	    n = read(SocketFD, RecvBuf, sizeof(RecvBuf)-1);
	    if (n < 0) 
	    {   FatalError(argv[0], "reading from socket failed");
	    }
	    RecvBuf[n] = 0;
	    /* Player recive the river cards from the server */
	    char * token = strtok(RecvBuf, ",");
         int p = 0;
        while( token != NULL ){
            if (p == 0){
                strcpy(board5, token);
            } 
            else if(p==1){
            strcpy(potstr, token);
            }
            token = strtok(NULL, ",");
            p++;
        }
	    board[4] = atoi(board5);
	    pot = atoi(potstr);
	    PrintBoard(board,pot);
	    printf("You win this round!!\n");
	    chips  += pot;
            printf("Your current balance is: %d\n", chips);
        }
	break;

	
} while(  (0 != strcmp("exit the server", RecvBuf))
	    &&(0 != strcmp("server shutdown", RecvBuf)));
    printf("%s: Exiting...\n", argv[0]);
    close(SocketFD);
    return 0;
}



/* EOF client2.c */

