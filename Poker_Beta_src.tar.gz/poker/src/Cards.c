/* Team 10 */
/* File name: Cards.c */
/* Author: Kevin Zhu & Pengfei Yan */
/* Creation Date: 2022/05/05 */
/* Modified Date: 2022/05/22 */

#include <stdio.h>
#include <stdlib.h>
#include "Cards.h"
#include <time.h>
#include <string.h>
#include "IO.h"
#include "Rules.h"

/*To creat the cards randomly(Shuffle) and store them into an array, so that they are easy to be handled*/
void creatcards(int cards_list[52]){
    int i = 0;
    int j;
    int r;
	srand((int)time(0));  
	for(int x = 0; x<52;x++){
	    while(i<52)
	    {
		    r=rand() % 52 + 1;  //genereate a random number between 1-52 
		    for(j=i;j>=0;j--)
		    {
			    if(r == cards_list[j])     //Compare with the random number that has been stored in to the array
				break;
	        } 
		    if(j<0)             //if the new one is not the same as we have, then store this one into the cardlist 
		    {
			    cards_list[i]=r;
			    i++;
		    }
	    }
	}
}

/* To deal the card from the deck of the cards to the players and dealer */
void Takecards(int cards_list[52],int index){
    int i,b,c;
    b = cards_list[index];
	//delete the "card"(number) from the deck of the cards, because it is been dealed to the players, and also 
	for(i=0;i<52;i++)
    {
        if(cards_list[i] == b)
		{
	        for(c=i;c<52;c++){
	            if(cards_list[c] != 0){
			        cards_list[c]=cards_list[c+1];
			    }
			    else{
			        cards_list[c] = 0;
			    }
	        }
			cards_list[51] = 0;
			i--; 		
		}
    }
    
}



/* To store the cards that the player or dealer obtained from the card deck*/
void StoreCards(int arr[2], int element){
    int i;
    for(i = 0;i < 2;i++){
        if(arr[i] == 0){
            arr[i] = element;
            break;
        }
    }
}

/* To store the cards of the board from the card deck*/
void Storeboard(int arr[5], int element){
    int i;
    for(i = 0;i < 5;i++){
        if(arr[i] == 0){
            arr[i] = element;
            break;
        }
    }
}