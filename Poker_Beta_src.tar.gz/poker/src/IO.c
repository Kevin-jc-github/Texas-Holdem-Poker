/* Team 10 */
/* File name: IO.c */
/* Author: Kevin Zhu */
/* Date: 2022/05/05 */


#include <stdio.h>
#include "Cards.h"
#include <stdlib.h>


//Print the Main game menu for the Poker
void PrintMenu(){
    printf("+--------------------------------------------------+\n");
    printf("|Welcome to the Texas Hold'em Poker Online Casino!!|\n");
    printf("+--------------------------------------------------+\n");
}

// To transfer the value of the card into the text form for the player to look at.
void GetCardText(int cardnumber){
    switch(cardnumber){
        
        case 1:
        printf("Club Ace\n");
        break;
        
        case 2:
        printf("Diamond Ace\n");
        break;
        
        case 3:
        printf("Heart Ace\n");
        break;
        
        case 4:
        printf("Spades Ace\n");
        break;
        
        case 5:
        printf("Club 2\n");
        break;
        
        case 6:
        printf("Diamond 2\n");
        break;
        
        case 7:
        printf("Heart 2\n");
        break;
        
        case 8:
        printf("Spades 2\n");
        break;
        
        case 9:
        printf("Club 3\n");
        break;
        
        case 10:
        printf("Diamond 3\n");
        break;
        
        case 11:
        printf("Heart 3\n");
        break;
        
        case 12:
        printf("Spades 3\n");
        break;
        
        case 13:
        printf("Club 4\n");
        break;
        
        case 14:
        printf("Diamond 4\n");
        break;
        
        case 15:
        printf("Heart 4\n");
        break;
        
        case 16:
        printf("Spades 4\n");
        break;
        
        case 17:
        printf("Club 5\n");
        break;
        
        case 18:
        printf("Diamond 5\n");
        break;
        
        case 19:
        printf("Heart 5\n");
        break;
        
        case 20:
        printf("Spades 5\n");
        break;
        
        case 21:
        printf("Club 6\n");
        break;
        
        case 22:
        printf("Diamond 6\n");
        break;
        
        case 23:
        printf("Heart 6\n");
        break;
        
        case 24:
        printf("Spades 6\n");
        break;
        
        case 25:
        printf("Club 7\n");
        break;
        
        case 26:
        printf("Diamond 7\n");
        break;
        
        case 27:
        printf("Heart 7\n");
        break;
        
        case 28:
        printf("Spades 7\n");
        break;
        
        case 29:
        printf("Club 8\n");
        break;
        
        case 30:
        printf("Diamond 8\n");
        break;
        
        case 31:
        printf("Heart 8\n");
        break;
        
        case 32:
        printf("Spades 8\n");
        break;
        
        case 33:
        printf("Club 9\n");
        break;
        
        case 34:
        printf("Diamond 9\n");
        break;
        
        case 35:
        printf("Heart 9\n");
        break;
        
        case 36:
        printf("Spades 9\n");
        break;
        
        case 37:
        printf("Club 10\n");
        break;
        
        case 38:
        printf("Diamond 10\n");
        break;
        
        case 39:
        printf("Heart 10\n");
        break;
        
        case 40:
        printf("Spades 10\n");
        break;
        
        case 41:
        printf("Club Jack\n");
        break;
        
        case 42:
        printf("Diamond Jack\n");
        break;
        
        case 43:
        printf("Heart Jack\n");
        break;
        
        case 44:
        printf("Spades Jack\n");
        break;
        
        case 45:
        printf("Club Queen\n");
        break;
        
        case 46:
        printf("Diamond Queen\n");
        break;
        
        case 47:
        printf("Heart Queen\n");
        break;
        
        case 48:
        printf("Spades Queen\n");
        break;
        
        case 49:
        printf("Club King\n");
        break;
        
        case 50:
        printf("Diamond King\n");
        break;
        
        case 51:
        printf("Heart King\n");
        break;
        
        case 52:
        printf("Spades King\n");
        break;
    }
}

// print the what cards do the players and the dealer have into GetCardText
void Printhands(int arr[2],int chip){
    int i;
    printf("\n");
    printf("Your hand is:\n");
    for(i = 0;i<2;i++){
        GetCardText(arr[i]);
    }
    printf("The current chips that you have is %d$\n",chip);
    printf("\n");
    printf("\n");
    printf("\n");
    printf("\n");
}

// Print out what we have on the board
void PrintBoard(int arr[5],int pot){
    int i;
    printf("The board cards are:\n");
    for(i = 0; i<5;i++){
        GetCardText(arr[i]);
    }
    printf("The current pot is:%d",pot);
    printf("\n");
}

char* itoa(int num,char* str,int radix)
{
    char index[]="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    unsigned unum;
    int i=0,j,k;
 
    
    if(radix==10&&num<0)
    {
        unum=(unsigned)-num;
        str[i++]='-';
    }
    else unum=(unsigned)num;
 
    
    do
    {
        str[i++]=index[unum%(unsigned)radix];
        unum/=radix;
 
    }while(unum);
 
    str[i]='\0';
 
    
    if(str[0]=='-') k=1;
    else k=0;
 
    char temp;
    for(j=k;j<=(i-1)/2;j++)
    {
        temp=str[j];
        str[j]=str[i-1+k-j];
        str[i-1+k-j]=temp;
    }
 
    return str;
 
}

// after the player fold, made the hand become zero
void MakeZero(int arr[2]){
    int i;
    for(i = 0; i<2 ;i++){
        arr[i] = 0;
    }
}