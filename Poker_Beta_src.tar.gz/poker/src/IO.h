/* Team 10 */
/* File name: IO.h */
/* Author: Kevin Zhu */
/* Date: 2022/05/05 */

#ifndef IO_H
#define IO_H

#include <stdio.h>
#include "Cards.h"
#include <stdlib.h>
#include <string.h>


char* itoa(int num,char* str,int radix);

/*Print the Main game menu for the Poker */
void PrintMenu();

/*To transfer the value of the card into the text form for the player to look at.*/
void GetCardText(int cardnumber);

/* print the what cards do the players and the dealer have into GetCardText*/
void Printhands(int arr[2], int chip);

/*Print out what we have on the board*/
void PrintBoard(int arr[5],int pot);

/*after the player fold, made the hand become zero*/
void MakeZero(int arr[2]);

#endif /* IO_H */
