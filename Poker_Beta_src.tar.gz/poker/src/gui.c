/*
 * Author: TianTian Lu 
 * modified date: 2022/5/24
 * */


#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>

gint delete_event(GtkWidget *widget, GdkEvent *event, gpointer data)
{
    g_print("You quit the poker game\n");
    return FALSE;
}

void destroy(GtkWidget *widget, gpointer data)
{
    gtk_main_quit ();
}

void changephoto(GtkWidget *widget, int w, int h, const gchar *path)
{
        
    gtk_widget_set_app_paintable(widget, TRUE);
    gtk_widget_realize(widget);
    gtk_widget_queue_draw(widget);

    GdkPixbuf *src = gdk_pixbuf_new_from_file(path, NULL);
    GdkPixbuf *dst = gdk_pixbuf_scale_simple(src, w, h, GDK_INTERP_BILINEAR);
    GdkPixmap *pix = NULL;
    
    gdk_pixbuf_render_pixmap_and_mask(dst, &pix, NULL, 128);
    gdk_window_set_back_pixmap(widget->window,pix,FALSE);
    
    g_object_unref(src);
    g_object_unref(dst);
    g_object_unref(pix);   

}
void enterbets(GtkWidget *widget, gpointer data)
{
    GtkWidget *window;
    GtkWidget *vbox;
    GtkWidget *image;
    GtkWidget *hbutton;
    GtkWidget *button1 , *button2, *button3, *button4;
    

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    g_signal_connect(G_OBJECT (window), "delete_event",G_CALLBACK(delete_event), NULL);
    g_signal_connect(G_OBJECT (window), "destroy",G_CALLBACK(destroy), NULL);
    gtk_window_set_default_size(GTK_WINDOW(window), 560, 560);
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);

    vbox = gtk_vbox_new(TRUE,10);
    gtk_container_add(GTK_CONTAINER(window),vbox);
    image = gtk_image_new_from_file("texaspoker.png");
    changephoto(window, 560,560,"texaspoker.png");
    //gtk_box_pack_start(GTK_BOX(vbox),image,TRUE,TRUE,0);
    
    hbutton = gtk_hbutton_box_new();
    gtk_container_add(GTK_CONTAINER(vbox), hbutton);
    button1 = gtk_button_new_with_label("Check");
    button2 = gtk_button_new_with_label("Fold");
    button3 = gtk_button_new_with_label("Raise");
    button4 = gtk_button_new_with_label("Call");
    gtk_container_add(GTK_CONTAINER(hbutton), button1);
    gtk_container_add(GTK_CONTAINER(hbutton), button2);
    gtk_container_add(GTK_CONTAINER(hbutton), button3);
    gtk_container_add(GTK_CONTAINER(hbutton), button4);
    gtk_widget_show_all(window);     
}
void NewWindow(GtkWidget *widget, gpointer data)
{
    GtkWidget *window;
    GtkWidget *button;
    GtkWidget *vbox;
    GtkWidget *entry;
    GtkWidget *label;
    // window for userinput
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    g_signal_connect(G_OBJECT (window), "delete_event",G_CALLBACK(delete_event), NULL);
    g_signal_connect(G_OBJECT (window), "destroy",G_CALLBACK(destroy), NULL);
    gtk_window_set_default_size(GTK_WINDOW(window), 560, 560);
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
    
    // create label
    vbox = gtk_vbox_new(TRUE, 10);
    gtk_container_add(GTK_CONTAINER(window),vbox);
    
    label  = gtk_label_new("Dear player, how much chips do you want to buy in before we start the game?(200$ to 600$)");
    gtk_container_add(GTK_CONTAINER(vbox),label);
    // create text entry
    entry = gtk_entry_new();
    gtk_entry_set_max_length(GTK_ENTRY(entry),50);
    g_signal_connect(entry, "activate",G_CALLBACK(enterbets),entry);
    gtk_box_pack_start(GTK_BOX(vbox), entry, TRUE,TRUE,0);

    gtk_widget_show_all(window);
    
    
}

int main (int argc, char *argv[])
{
    GtkWidget *window;   // the whole window
    GtkWidget *vbox;     // first vbox for welcome
    GtkWidget *button1;  // button for begin
    GtkWidget *button2;  // button for quit
    GtkWidget *Hbutton;  // button for bottom
    GtkWidget *label;    // welcome message
    

    gtk_init(&argc, &argv);
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

    g_signal_connect(G_OBJECT (window), "delete_event",G_CALLBACK(delete_event), NULL);
    g_signal_connect(G_OBJECT (window), "destroy",G_CALLBACK(destroy), NULL);
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
    gtk_window_set_default_size(GTK_WINDOW(window), 560, 560);

    
    vbox = gtk_vbox_new(TRUE, 10);
    gtk_container_add(GTK_CONTAINER(window), vbox);

    label = gtk_label_new("Welcome to the texas poker game");
    gtk_container_add(GTK_CONTAINER(vbox), label);

    button1 = gtk_button_new_with_label("Start game");
    g_signal_connect(button1, "clicked",G_CALLBACK(NewWindow),NULL);
    
    button2 = gtk_button_new_with_label("Quit");
    g_signal_connect_swapped(button2, "clicked",G_CALLBACK(gtk_widget_destroy),window);
 
    Hbutton = gtk_hbutton_box_new();
    gtk_container_add(GTK_CONTAINER(vbox), Hbutton);
    gtk_container_add(GTK_CONTAINER(Hbutton), button1);
    gtk_container_add(GTK_CONTAINER(Hbutton), button2);

    gtk_widget_show_all(window);
    gtk_main();
    return 0;

}



