/* Team 10 */
/* File name: Rules.h */
/* Author: Kevin Zhu & Pengfei Yan */
/* Creation Date: 2022/05/08 */
/* Modified Date: 2022/05/22 */

#ifndef Rules_H
#define Rules_H

#include "Cards.h"
#include "IO.h"

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

/* To the give order to 5 cards from increasingly*/
void OrderCards(int arr[5]);

/*Get the value of one card*/
int GetCardValue(int car);

/*Get the suit  of one card*/
int GetCardSuit(int car);

/*Get the type of five given cards*/
int GetCardType(int car[5]);

/*Get the biggest type of a player*/
int GetBiggestType(int privatec[2], int publicc[5]);

/*Get the position(0-7) of the biggest type of a player in an array */
void GetBigPosition(int privatec[2], int publicc[5], int outarr[5]);

/*sort some values to an increasing order*/
void ordervalue(int a[], int len);

/*Compare the type of two players, return 1 if player1 has a bigger hand, 0 if player2 has a bigger hand, 2 if they are the same*/
int CompareTwoPlayer(int player1[2], int player2[2], int board[5]);

/*Compare the type of two players for Highcard, return 1 if player1 has a bigger hand, 0 if player2 has a bigger hand, 2 if they are the same*/
int Compare1(int player1[2], int player2[2], int board[5]);

/*Compare the type of two players for pair, return 1 if player1 has a bigger hand, 0 if player2 has a bigger hand, 2 if they are the same*/
int Compare2(int player1[2], int player2[2], int board[5]);

/*Compare the type of two players for two pairs, return 1 if player1 has a bigger hand, 0 if player2 has a bigger hand, 2 if they are the same*/
int Compare3(int player1[2], int player2[2], int board[5]);

/*Compare the type of two players for Threeofakind, return 1 if player1 has a bigger hand, 0 if player2 has a bigger hand, 2 if they are the same*/
int Compare4(int player1[2], int player2[2], int board[5]);

/*Compare the type of two players for Straight, return 1 if player1 has a bigger hand, 0 if player2 has a bigger hand, 2 if they are the same*/
int Compare5(int player1[2], int player2[2], int board[5]);

/*Compare the type of two players for Flush, return 1 if player1 has a bigger hand, 0 if player2 has a bigger hand, 2 if they are the same*/
int Compare6(int player1[2], int player2[2], int board[5]);

/*Compare the type of two players for Fullhouse, return 1 if player1 has a bigger hand, 0 if player2 has a bigger hand, 2 if they are the same*/
int Compare7(int player1[2], int player2[2], int board[5]);

/*Compare the type of two players for Quads, return 1 if player1 has a bigger hand, 0 if player2 has a bigger hand, 2 if they are the same*/
int Compare8(int player1[2], int player2[2], int board[5]);

/*Compare the type of two players for Straightflush, return 1 if player1 has a bigger hand, 0 if player2 has a bigger hand, 2 if they are the same*/
int Compare9(int player1[2], int player2[2], int board[5]);

#endif /* Rules_H */