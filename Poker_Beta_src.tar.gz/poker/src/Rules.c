/* Team 10 */
/* File name: Rules.c */
/* Author: Kevin Zhu & Pengfei Yan */
/* Creation Date: 2022/05/08 */
/* Modified Date: 2022/05/22 */

#include "Cards.h"
#include "IO.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// To the give order to 5 cards from increasingly
void OrderCards(int arr[5]){
	int newarr[5];
	int i;
	int t;
	
	for(t = 0; t < 5; t++){
		int min = 15;
		int j;
		for(i = 0; i < 5; i++)
		{
			if(GetCardValue(arr[i])<min){ //find a smallest card
				min = GetCardValue(arr[i]);
				j = i;
			}
		}
	newarr[t] = arr[j];
	arr[j] = 0;
	}

	for(i = 0; i < 5; i++){ //change the number in array
		arr[i] = newarr[i];
	}
}

//Get the value of one card
int GetCardValue(int car){
    if(car == 1 || car == 2 || car == 3 || car == 4){ // when the card is 1
        return 14;
    }
    else if(car == 5 || car == 6 || car == 7 || car == 8){ // when the card is 2 
        return 2;
    }
    else if(car == 9 || car == 10 || car == 11 || car == 12){// when the card is 3
        return 3;
    }
    else if(car == 13 || car == 14 || car == 15 || car == 16){// when the card is 4
        return 4;
    }
    else if(car == 17 || car == 18 || car == 19 || car == 20){// when the card is 5
        return 5;
    }
    else if(car == 21 || car == 22 || car == 23 || car == 24){// when the card is 6
        return 6;
    }
    else if(car == 25 || car == 26 || car == 27 || car == 28){// when the card is 7
        return 7;
    }
    else if(car == 29 || car == 30 || car == 31 || car == 32){// when the card is 8
        return 8;
    }
    else if(car == 33 || car == 34 ||  car == 35 || car == 36){// when the card is 9
        return 9;
    }
    else if(car == 37 || car == 38 ||  car == 39 || car == 40){// when the card is 10
        return 10;
    }
    else if(car == 41 || car == 42 ||  car == 43 || car == 44){// when the card is J
        return 11;
    }
    else if(car == 45 || car == 46 ||  car == 47 || car == 48){// when the card is Q
        return 12;
    }
    else if(car == 49 || car == 50 ||  car == 51 || car == 52){// when the card is K
        return 13;
    }
    return 99;
}

//Get the suit  of one card
int GetCardSuit(int car){
    if(car == 0){ //the card is NULL
        return 99;
    }
    else if(car%4 == 0){ //when the card is Spades
        return 4;
    }
    else{ //when the card os not Spades
        return car%4;
    }
}

//Get the type of five given cards
int GetCardType(int car[5]){
    int newarr[5];
    int i;
    int s1, s2, s3, s4, s5; //suits of cards
    int v1, v2, v3, v4, v5; //value of cards

    for(i = 0; i < 5; i++){ //create a new array to avoid change the original array
        newarr[i] = car[i];
    }
    OrderCards(newarr);

    s1 = GetCardSuit(newarr[0]);
    s2 = GetCardSuit(newarr[1]);
    s3 = GetCardSuit(newarr[2]);
    s4 = GetCardSuit(newarr[3]);
    s5 = GetCardSuit(newarr[4]);

    v1 = GetCardValue(newarr[0]);
    v2 = GetCardValue(newarr[1]);
    v3 = GetCardValue(newarr[2]);
    v4 = GetCardValue(newarr[3]);
    v5 = GetCardValue(newarr[4]);

    //case of Straightflush
    if((s1 == s2) & (s2 == s3) & (s3 == s4) & (s4 == s5) & (v2 == (v1 + 1)) & (v3 == (v2 + 1)) & (v4 == (v3 + 1)) & (v5 == (v4 + 1))){
        return 9;
    }
    //case of Flush
    else if((s1 == s2) & (s2 == s3) & (s3 == s4) & (s4 == s5)){
        return 6;
    }
    //case of Straight
    else if(((v2 == (v1 + 1)) & (v3 == (v2 + 1)) &( v4 == (v3 + 1) ))& (v5 == (v4 + 1))){
        return 5;
    }
    //case of Quads
    else if( ((v1 == v2) & (v2 == v3) & (v3 == v4)) || ((v2 == v3) & (v3 == v4) & (v4 == v5))){
        return 8;
    }
    //case of Fullhouse
    else if( ((v1 == v2) & (v2 == v3) & (v4 == v5))||((v1 == v2) & (v3 == v4) & (v4 == v5)) ){
        return 7;
    }
    //case of Three of a kind
    else if( ((v1 == v2) & (v2 == v3))||((v2 == v3) & (v3 == v4))||((v3 == v4) & (v4 == v5)) ){
        return 4;
    }
    //case of two pairs
    else if( ((v1 == v2) & (v3 == v4))||((v2 == v3) & (v4 == v5))||((v1 == v2 )& (v4 == v5)) ){
        return 3;
    }
    //case of one pair
    else if((v1 == v2 )|| (v2 == v3) || (v3 == v4 )|| (v4 == v5)){
        return 2;
    }
    //case of highcard
    else{
        return 1;
    }
}

//Get the biggest type of a player
int GetBiggestType(int privatec[2], int publicc[5]){
    int bt = 0; //biggest type
    int t[5]; //temp array to be tested
    int a[7] = {privatec[0], privatec[1], publicc[0], publicc[1], publicc[2], publicc[3], publicc[4]}; //temp array of all 7 cards

    //case 1 that 1st and 2nd cards is not in biggest situation
    t[0] = a[2];
    t[1] = a[3];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 2 that 1st and 3rd cards is not in biggest situation
    t[0] = a[1];
    t[1] = a[3];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 3
    t[0] = a[1];
    t[1] = a[2];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 4
    t[0] = a[1];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 5
    t[0] = a[1];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 6
    t[0] = a[1];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[5];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 7
    t[0] = a[0];
    t[1] = a[3];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 8
    t[0] = a[0];
    t[1] = a[2];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 9
    t[0] = a[0];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 10
    t[0] = a[0];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 11
    t[0] = a[0];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[5];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 12
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 13
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[3];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 14
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 15
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[5];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 16
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 17
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[4];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 18
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[4];
    t[4] = a[5];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 19
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[3];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 20
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[3];
    t[4] = a[5];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 21
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[3];
    t[4] = a[4];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    return bt;
}


//Get the position(0-7) of the biggest type of a player in an array 
void GetBigPosition(int privatec[2], int publicc[5], int outarr[5]){
    int bt = 0; //biggest type
    int t[5]; //temp array to be tested
    int a[7] = {privatec[0], privatec[1], publicc[0], publicc[1], publicc[2], publicc[3], publicc[4]}; //temp array of all 7 cards

    //case 1 that 1st and 2nd cards is not in biggest situation
    t[0] = a[2];
    t[1] = a[3];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) >= bt){
        bt = GetCardType(t);
        outarr[0] = 2;
        outarr[1] = 3;
        outarr[2] = 4;
        outarr[3] = 5;
        outarr[4] = 6;
    }

    //case 2 that 1st and 3rd cards is not in biggest situation
    t[0] = a[1];
    t[1] = a[3];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) >= bt){
        bt = GetCardType(t);
        outarr[0] = 1;
        outarr[1] = 3;
        outarr[2] = 4;
        outarr[3] = 5;
        outarr[4] = 6;
    }

    //case 3
    t[0] = a[1];
    t[1] = a[2];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) >= bt){
        bt = GetCardType(t);
        outarr[0] = 1;
        outarr[1] = 2;
        outarr[2] = 4;
        outarr[3] = 5;
        outarr[4] = 6;
    }

    //case 4
    t[0] = a[1];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) >= bt){
        bt = GetCardType(t);
        outarr[0] = 1;
        outarr[1] = 2;
        outarr[2] = 3;
        outarr[3] = 5;
        outarr[4] = 6;
    }

    //case 5
    t[0] = a[1];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[6];
    if(GetCardType(t) >= bt){
        bt = GetCardType(t);
        outarr[0] = 1;
        outarr[1] = 2;
        outarr[2] = 3;
        outarr[3] = 4;
        outarr[4] = 6;
    }

    //case 6
    t[0] = a[1];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[5];
    if(GetCardType(t) >= bt){
        bt = GetCardType(t);
        outarr[0] = 1;
        outarr[1] = 2;
        outarr[2] = 3;
        outarr[3] = 4;
        outarr[4] = 5;
    }

    //case 7
    t[0] = a[0];
    t[1] = a[3];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) >= bt){
        bt = GetCardType(t);
        outarr[0] = 0;
        outarr[1] = 3;
        outarr[2] = 4;
        outarr[3] = 5;
        outarr[4] = 6;
    }

    //case 8
    t[0] = a[0];
    t[1] = a[2];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) >= bt){
        bt = GetCardType(t);
        outarr[0] = 0;
        outarr[1] = 2;
        outarr[2] = 4;
        outarr[3] = 5;
        outarr[4] = 6;
    }

    //case 9
    t[0] = a[0];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) >= bt){
        bt = GetCardType(t);
        outarr[0] = 0;
        outarr[1] = 2;
        outarr[2] = 3;
        outarr[3] = 5;
        outarr[4] = 6;
    }

    //case 10
    t[0] = a[0];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[6];
    if(GetCardType(t) >= bt){
        bt = GetCardType(t);
        outarr[0] = 0;
        outarr[1] = 2;
        outarr[2] = 3;
        outarr[3] = 4;
        outarr[4] = 6;
    }

    //case 11
    t[0] = a[0];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[5];
    if(GetCardType(t) >= bt){
        bt = GetCardType(t);
        outarr[0] = 0;
        outarr[1] = 2;
        outarr[2] = 3;
        outarr[3] = 4;
        outarr[4] = 5;
    }

    //case 12
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) >= bt){
        bt = GetCardType(t);
        outarr[0] = 0;
        outarr[1] = 1;
        outarr[2] = 4;
        outarr[3] = 5;
        outarr[4] = 6;
    }

    //case 13
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[3];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) >= bt){
        bt = GetCardType(t);
        outarr[0] = 0;
        outarr[1] = 1;
        outarr[2] = 3;
        outarr[3] = 5;
        outarr[4] = 6;
    }

    //case 14
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[6];
    if(GetCardType(t) >= bt){
        bt = GetCardType(t);
        outarr[0] = 0;
        outarr[1] = 1;
        outarr[2] = 3;
        outarr[3] = 4;
        outarr[4] = 6;
    }

    //case 15
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[5];
    if(GetCardType(t) >= bt){
        bt = GetCardType(t);
        outarr[0] = 0;
        outarr[1] = 1;
        outarr[2] = 3;
        outarr[3] = 4;
        outarr[4] = 5;
    }

    //case 16
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) >= bt){
        bt = GetCardType(t);
        outarr[0] = 0;
        outarr[1] = 1;
        outarr[2] = 2;
        outarr[3] = 5;
        outarr[4] = 6;
    }

    //case 17
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[4];
    t[4] = a[6];
    if(GetCardType(t) >= bt){
        bt = GetCardType(t);
        outarr[0] = 0;
        outarr[1] = 1;
        outarr[2] = 2;
        outarr[3] = 4;
        outarr[4] = 6;
    }

    //case 18
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[4];
    t[4] = a[5];
    if(GetCardType(t) >= bt){
        bt = GetCardType(t);
        outarr[0] = 0;
        outarr[1] = 1;
        outarr[2] = 2;
        outarr[3] = 4;
        outarr[4] = 5;
    }

    //case 19
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[3];
    t[4] = a[6];
    if(GetCardType(t) >= bt){
        bt = GetCardType(t);
        outarr[0] = 0;
        outarr[1] = 1;
        outarr[2] = 2;
        outarr[3] = 3;
        outarr[4] = 6;
    }

    //case 20
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[3];
    t[4] = a[5];
    if(GetCardType(t) >= bt){
        bt = GetCardType(t);
        outarr[0] = 0;
        outarr[1] = 1;
        outarr[2] = 2;
        outarr[3] = 3;
        outarr[4] = 5;
    }

    //case 21
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[3];
    t[4] = a[4];
    if(GetCardType(t) >= bt){
        bt = GetCardType(t);
        outarr[0] = 0;
        outarr[1] = 1;
        outarr[2] = 2;
        outarr[3] = 3;
        outarr[4] = 4;
    }
}

//sort some values to an increasing order
void ordervalue(int a[], int len){
    int i,j,temp;
 
    for (i = 0 ; i < len - 1 ; i++) 
    {
        int min = i;    
        for (j = i + 1; j < len; j++) 
        {
            if (a[j] < a[min])    
            {
                min = j;    
            }
        }
        if(min != i)
        {
            temp = a[min];  
            a[min] = a[i];
            a[i] = temp;
        }
        
    }
}

//Compare the type of two players, return 1 if player1 has a bigger hand, 0 if player2 has a bigger hand, 2 if they are the same
int CompareTwoPlayer(int player1[2], int player2[2], int board[5])
{
    int v1 = GetBiggestType(player1, board);
    int v2 = GetBiggestType(player2, board);
    if(v1 > v2){ //Player1 has a bigger type 
        return 1;
    }
    else if(v1 < v2){ //Player2 has a bigger type 
        return 0;
    }
    else{ //Player1 and Player2 have same type, further comparing is needed
        if(v1 == 1){ //case for highcard
            return Compare1(player1, player2, board);
        }
        else if(v1 == 2){ //case for one pair
            return Compare2(player1, player2, board);
        }
        else if(v1 == 3){ //case for two pairs
            return Compare3(player1, player2, board);
        }
        else if(v1 == 4){ //case for three of a kind
            return Compare4(player1, player2, board);
        }
        else if(v1 == 5){ //case for Straight
            return Compare5(player1, player2, board);
        }
        else if(v1 == 6){ //case for Flush
            return Compare6(player1, player2, board);
        }
        else if(v1 == 7){ //case for Fullhouse
            return Compare7(player1, player2, board);
        }
        else if(v1 == 8){ //case for Quads
            return Compare8(player1, player2, board);
        }
        else if(v1 == 9){ //case for Straightflush
            return Compare9(player1, player2, board);
        }
    }
    return 0;
}

//Compare the type of two players for Highcard, return 1 if player1 has a bigger hand, 0 if player2 has a bigger hand, 2 if they are the same
int Compare1(int player1[2], int player2[2], int board[5]){
    int c1[7] = {player1[0], player1[1], board[0], board[1], board[2], board[3], board[4]};
    int c2[7] = {player2[0], player2[1], board[0], board[1], board[2], board[3], board[4]};
    int arr1[7] = {0, 0, 0, 0, 0, 0, 0};
    int arr2[7] = {0, 0, 0, 0, 0, 0, 0};
    int i;

    for(i = 0; i < 7; i++){
        arr1[i] = GetCardValue(c1[i]);
        arr2[i] = GetCardValue(c2[i]);
    }

    ordervalue(arr1, 7);
    ordervalue(arr2, 7);


    if(arr1[6] > arr2[6]){
        return 1;
    }
    else if(arr1[6] < arr2[6]){
        return 0;
    }
    else{
        if(arr1[5] > arr2[5]){
            return 1;
        }
        else if(arr1[5] < arr2[5]){
            return 0;
        }
        else{
            if(arr1[4] > arr2[4]){
                return 1;
            }
            else if(arr1[4] < arr2[4]){
                return 0;
            }
            else{
                if(arr1[3] > arr2[3]){
                    return 1;
                }
                else if(arr1[3] < arr2[3]){
                    return 0;
                }
                else{
                    if(arr1[2] > arr2[2]){
                        return 1;
                    }
                    else if(arr1[2] < arr2[2]){
                        return 0;
                    }
                    else{
                        return 2;
                    }
                }
            }
        }
    }
}

//Compare the type of two players for pair, return 1 if player1 has a bigger hand, 0 if player2 has a bigger hand, 2 if they are the same
int Compare2(int player1[2], int player2[2], int board[5]){
    int c1[7] = {player1[0], player1[1], board[0], board[1], board[2], board[3], board[4]};
    int c2[7] = {player2[0], player2[1], board[0], board[1], board[2], board[3], board[4]};
    int p1; //pair part
    int p2;
    int arr1[7] = {0, 0, 0, 0, 0, 0, 0};
    int arr2[7] = {0, 0, 0, 0, 0, 0, 0};
    int rest1[3] = {0, 0, 0}; //rest cards
    int rest2[3] = {0, 0, 0};
    int i;

    for(i = 0; i < 7; i++){
        arr1[i] = GetCardValue(c1[i]);
        arr2[i] = GetCardValue(c2[i]);
    }

    ordervalue(arr1, 7);
    ordervalue(arr2, 7);

    //find 5 biggest cards for player 1
    //case 1 that 7 cards are: ABCDEFF
    if(arr1[5] == arr1[6]){
        p1 = arr1[5];
        rest1[0] = arr1[2];
        rest1[1] = arr1[3];
        rest1[2] = arr1[4];
    }
    //case 2 that 7 cards are: ABCDEEF
    else if(arr1[4] == arr1[5]){
        p1 = arr1[4];
        rest1[0] = arr1[2];
        rest1[1] = arr1[3];
        rest1[2] = arr1[6];
    }
    //case 3 that 7 cards are: ABCDDEF
    else if(arr1[3] == arr1[4]){
        p1 = arr1[3];
        rest1[0] = arr1[2];
        rest1[1] = arr1[5];
        rest1[2] = arr1[6];
    }
    //case 4: ABCCDEF
    else if(arr1[2] == arr1[3]){
        p1 = arr1[2];
        rest1[0] = arr1[4];
        rest1[1] = arr1[5];
        rest1[2] = arr1[6];
    }
    //case 5: ABBCDEF
    else if(arr1[1] == arr1[2]){
        p1 = arr1[1];
        rest1[0] = arr1[4];
        rest1[1] = arr1[5];
        rest1[2] = arr1[6];
    }
    //case 6: AABCDEF
    else if(arr1[0] == arr1[1]){
        p1 = arr1[0];
        rest1[0] = arr1[4];
        rest1[1] = arr1[5];
        rest1[2] = arr1[6];
    }

    //find 5 biggest cards for player 2
    //case 1 that 7 cards are: ABCDEFF
    if(arr2[5] == arr2[6]){
        p2 = arr2[5];
        rest2[0] = arr2[2];
        rest2[1] = arr2[3];
        rest2[2] = arr2[4];
    }
    //case 2 that 7 cards are: ABCDEEF
    else if(arr2[4] == arr2[5]){
        p2 = arr2[4];
        rest2[0] = arr2[2];
        rest2[1] = arr2[3];
        rest2[2] = arr2[6];
    }
    //case 3 that 7 cards are: ABCDDEF
    else if(arr2[3] == arr2[4]){
        p2 = arr2[3];
        rest2[0] = arr2[2];
        rest2[1] = arr2[5];
        rest2[2] = arr2[6];
    }
    //case 4: ABCCDEF
    else if(arr2[2] == arr2[3]){
        p2 = arr2[2];
        rest2[0] = arr2[4];
        rest2[1] = arr2[5];
        rest2[2] = arr2[6];
    }
    //case 5: ABBCDEF
    else if(arr2[1] == arr2[2]){
        p2 = arr2[1];
        rest2[0] = arr2[4];
        rest2[1] = arr2[5];
        rest2[2] = arr2[6];
    }
    //case 6: AABCDEF
    else if(arr2[0] == arr2[1]){
        p2 = arr2[0];
        rest2[0] = arr2[4];
        rest2[1] = arr2[5];
        rest2[2] = arr2[6];
    }

    //compare
    if(p1 > p2){
        return 1;
    }
    else if(p1 < p2){
        return 0;
    }
    else{
        if(rest1[2] > rest2[2]){
            return 1;
        }
        else if(rest1[2] < rest2[2]){
            return 0;
        }
        else{
            if(rest1[1] > rest2[1]){
                return 1;
            }
            else if(rest1[1] < rest2[1]){
                return 0;
            }
            else{
                if(rest1[0] > rest2[0]){
                    return 1;
                }
                else if(rest1[0] < rest2[0]){
                    return 0;
                }
                else{
                    return 2;
                }
            }
        }
    }
}

//Compare the type of two players for two pairs, return 1 if player1 has a bigger hand, 0 if player2 has a bigger hand, 2 if they are the same
int Compare3(int player1[2], int player2[2], int board[5]){
    int dd1; // big pair
    int dd2;
    int xd1; // small pair
    int xd2;
    int r1; //rest card
    int r2;
    int t1[7] = {player1[0], player1[1], board[0], board[1], board[2], board[3], board[4]};
    int t2[7] = {player2[0], player2[1], board[0], board[1], board[2], board[3], board[4]};
    int tv1[7] = {0, 0, 0, 0, 0, 0, 0}; //array of the valve of 7 cards
    int tv2[7] = {0, 0, 0, 0, 0, 0, 0};
    int i;

    for(i = 0; i < 7; i++){
        tv1[i] = GetCardValue(t1[i]);
    }

    for(i = 0; i < 7; i++){
        tv2[i] = GetCardValue(t2[i]);
    }

    ordervalue(tv1, 7);
    ordervalue(tv2, 7);

    //case 1: AABBCDE
    if((tv1[0] == tv1[1]) & (tv1[2] == tv1[3])){
        xd1 = tv1[0];
        dd1 = tv1[2];
        r1 = tv1[6];
    }
    //case 2: AABCCDE
    else if((tv1[0] == tv1[1]) & (tv1[3] == tv1[4])){
        xd1 = tv1[0];
        dd1 = tv1[3];
        r1 = tv1[6];
    }
    //case 3: AABCDDE
    else if((tv1[0] == tv1[1]) & (tv1[2] == tv1[3])){
        xd1 = tv1[0];
        dd1 = tv1[4];
        r1 = tv1[6];
    }
    //case 4: AABCDEE
    else if((tv1[0] == tv1[1]) & (tv1[2] == tv1[3])){
        xd1 = tv1[0];
        dd1 = tv1[5];
        r1 = tv1[4];
    }
    //case 5: ABBCCDE
    else if((tv1[1] == tv1[2]) & (tv1[3] == tv1[4])){
        xd1 = tv1[1];
        dd1 = tv1[3];
        r1 = tv1[6];
    }
    //case 6: ABBCDDE
    else if((tv1[1] == tv1[2]) & (tv1[4] == tv1[5])){
        xd1 = tv1[1];
        dd1 = tv1[4];
        r1 = tv1[6];
    }
    //case 7: ABBCDEE
    else if((tv1[1] == tv1[2]) & (tv1[5] == tv1[6])){
        xd1 = tv1[1];
        dd1 = tv1[5];
        r1 = tv1[4];
    }
    //case 8: ABCCDDE
    else if((tv1[2] == tv1[3]) & (tv1[4] == tv1[5])){
        xd1 = tv1[2];
        dd1 = tv1[4];
        r1 = tv1[6];
    }
    //case 9: ABCCDEE
    else if((tv1[2] == tv1[3]) & (tv1[5] == tv1[6])){
        xd1 = tv1[2];
        dd1 = tv1[5];
        r1 = tv1[4];
    }
    //case 10:ABCDDEE
    else if((tv1[3] == tv1[4]) & (tv1[5] == tv1[6])){
        xd1 = tv1[3];
        dd1 = tv1[5];
        r1 = tv1[2];
    }

    //case 1: AABBCDE
    if((tv2[0] == tv2[1]) & (tv2[2] == tv2[3])){
        xd2 = tv2[0];
        dd2 = tv2[2];
        r2 = tv2[6];
    }
    //case 2: AABCCDE
    else if((tv2[0] == tv2[1]) & (tv2[3] == tv2[4])){
        xd2 = tv2[0];
        dd2 = tv2[3];
        r2 = tv2[6];
    }
    //case 3: AABCDDE
    else if((tv2[0] == tv2[1]) & (tv2[2] == tv2[3])){
        xd2 = tv2[0];
        dd2 = tv2[4];
        r2 = tv2[6];
    }
    //case 4: AABCDEE
    else if((tv2[0] == tv2[1]) & (tv2[2] == tv2[3])){
        xd2 = tv2[0];
        dd2 = tv2[5];
        r2 = tv2[4];
    }
    //case 5: ABBCCDE
    else if((tv2[1] == tv2[2]) & (tv2[3] == tv2[4])){
        xd2 = tv2[1];
        dd2 = tv2[3];
        r2 = tv2[6];
    }
    //case 6: ABBCDDE
    else if((tv2[1] == tv2[2]) & (tv2[4] == tv2[5])){
        xd2 = tv2[1];
        dd2 = tv2[4];
        r2 = tv2[6];
    }
    //case 7: ABBCDEE
    else if((tv2[1] == tv2[2]) & (tv2[5] == tv2[6])){
        xd2 = tv2[1];
        dd2 = tv2[5];
        r2 = tv2[4];
    }
    //case 8: ABCCDDE
    else if((tv2[2] == tv2[3]) & (tv2[4] == tv2[5])){
        xd2 = tv2[2];
        dd2 = tv2[4];
        r2 = tv2[6];
    }
    //case 9: ABCCDEE
    else if((tv2[2] == tv2[3]) & (tv2[5] == tv2[6])){
        xd2 = tv2[2];
        dd2 = tv2[5];
        r2 = tv2[4];
    }
    //case 10:ABCDDEE
    else if((tv2[3] == tv2[4]) & (tv2[5] == tv2[6])){
        xd2 = tv2[3];
        dd2 = tv2[5];
        r2 = tv2[2];
    }

    if(dd1 > dd2){
        return 1;
    }
    else if(dd1 < dd2){
        return 0;
    }
    else{
        if(xd1 > xd2){
            return 1;
        }
    else if(xd1 < xd2){
            return 0;
        }
        else{
            if(r1 > r2){
                return 1;
            }
            else if(r1 < r2){
                return 0;
            }
            else{
                return 2;
            }
        }
    }
}

//Compare the type of two players for Threeofakind, return 1 if player1 has a bigger hand, 0 if player2 has a bigger hand, 2 if they are the same
int Compare4(int player1[2], int player2[2], int board[5]){
    int san1; //value of three of a kind cards 
    int san2;
    int r1[2] = {0, 0}; //value of rest two cards
    int r2[2] = {0, 0};
    int t1[7] = {player1[0], player1[1], board[0], board[1], board[2], board[3], board[4]};
    int t2[7] = {player2[0], player2[1], board[0], board[1], board[2], board[3], board[4]};
    int tv1[7] = {0, 0, 0, 0, 0, 0, 0}; //array of the valve of 7 cards
    int tv2[7] = {0, 0, 0, 0, 0, 0, 0};
    int i;

    for(i = 0; i < 7; i++){
        tv1[i] = GetCardValue(t1[i]);
    }

    for(i = 0; i < 7; i++){
        tv2[i] = GetCardValue(t2[i]);
    }

    ordervalue(tv1, 7);
    ordervalue(tv2, 7);

    //case 1: AAABCDE
    if((tv1[0] == tv1[1]) & (tv1[1] == tv1[2])){
        san1 = tv1[0];
        r1[0] = tv1[5];
        r1[1] = tv1[6];
    }
    //case 2: ABBBCDE
    else if((tv1[1] == tv1[2]) & (tv1[2] == tv1[3])){
        san1 = tv1[1];
        r1[0] = tv1[5];
        r1[1] = tv1[6];
    }
    //case 3: ABCCCDE
    else if((tv1[2] == tv1[3]) & (tv1[3] == tv1[4])){
        san1 = tv1[2];
        r1[0] = tv1[5];
        r1[1] = tv1[6];
    }
    //case 4: ABCDDDE
    else if((tv1[3] == tv1[4]) & (tv1[4] == tv1[5])){
        san1 = tv1[3];
        r1[0] = tv1[2];
        r1[1] = tv1[6];
    }
    //case 5: ABCDEEE
    else{
        san1 = tv1[4];
        r1[0] = tv1[2];
        r1[1] = tv1[3];
    }

    //case 1: AAABCDE
    if((tv2[0] == tv2[1]) & (tv2[1] == tv2[2])){
        san2 = tv2[0];
        r2[0] = tv2[5];
        r2[1] = tv2[6];
    }
    //case 2: ABBBCDE
    else if((tv2[1] == tv2[2]) & (tv2[2] == tv2[3])){
        san2 = tv2[1];
        r2[0] = tv2[5];
        r2[1] = tv2[6];
    }
    //case 3: ABCCCDE
    else if((tv2[2] == tv2[3]) & (tv2[3] == tv2[4])){
        san2 = tv2[2];
        r2[0] = tv2[5];
        r2[1] = tv2[6];
    }
    //case 4: ABCDDDE
    else if((tv2[3] == tv2[4]) & (tv2[4] == tv2[5])){
        san2 = tv2[3];
        r2[0] = tv2[2];
        r2[1] = tv2[6];
    }
    //case 5: ABCDEEE
    else{
        san2 = tv2[4];
        r2[0] = tv2[2];
        r2[1] = tv2[3];
    }

    if(san1 > san2){
        return 1;
    }
    else if(san1 < san2){
        return 0;
    }
    else{
        if(r1[0] > r2[0]){
            return 1;
        }
        else if(r1[0] < r2[0]){
            return 0;
        }
        else{
            if(r1[1] > r2[1]){
                return 1;
            }
            else if(r1[1] < r2[1]){
                return 0;
            }
            else{
                return 2;
            }
        }
    }
}

//Compare the type of two players for Straight, return 1 if player1 has a bigger hand, 0 if player2 has a bigger hand, 2 if they are the same
int Compare5(int player1[2], int player2[2], int board[5]){
    int arr1[5] = {0, 0, 0, 0, 0};
    int arr2[5] = {0, 0, 0, 0, 0};
    int p1[5] = {0, 0, 0, 0, 0};
    int p2[5] = {0, 0, 0, 0, 0};
    int c1[7] = {player1[0], player1[1], board[0], board[1], board[2], board[3], board[4]};
    int c2[7] = {player2[0], player2[1], board[0], board[1], board[2], board[3], board[4]};
    int i;

    GetBigPosition(player1, board, p1);
    GetBigPosition(player2, board, p2);

    for(i = 0; i < 5; i++){
        arr1[i] = GetCardValue(c1[p1[i]]);
    }
    
    for(i = 0; i < 5; i++){
        arr2[i] = GetCardValue(c2[p2[i]]);
    }

    ordervalue(arr1, 5);
    ordervalue(arr2, 5);
    

    if(arr1[0] > arr2[0]){
        return 1;
    }
    else if(arr1[0] < arr2[0]){
        return 0;
    }
    else{
        return 2;
    }
}

//Compare the type of two players for Flush, return 1 if player1 has a bigger hand, 0 if player2 has a bigger hand, 2 if they are the same
int Compare6(int player1[2], int player2[2], int board[5]){

    int t1[7] = {player1[0], player1[1], board[0], board[1], board[2], board[3], board[4]};
    int t2[7] = {player2[0], player2[1], board[0], board[1], board[2], board[3], board[4]};

    int tv1[7] = {0, 0, 0, 0, 0, 0, 0};//array of the valve of 7 cards
    int tv2[7] = {0, 0, 0, 0, 0, 0, 0};

    int b1[5] = {0, 0, 0, 0, 0};
    int b2[5] = {0, 0, 0, 0, 0};

    int arr1[5] = {0, 0, 0, 0, 0};
    int arr2[5] = {0, 0, 0, 0, 0};

    int n1 = 0; //number of cards in a suit
    int n2 = 0;
    int s1; //suit
    int s2;
    int i;
    int j;

    GetBigPosition(player1, board, b1);
    GetBigPosition(player2, board, b2);
    
    s1 = GetCardSuit(t1[b1[0]]);
    s2 = GetCardSuit(t2[b2[0]]);

    for(i = 0; i < 7; i++){
        if(GetCardSuit(t1[i]) == s1){
            n1++;
        }
    }

    for(i = 0; i < 7; i++){
        if(GetCardSuit(t2[i]) == s2){
            n2++;
        }
    }

    if(n1 == 7){
        for(i = 0; i < 7; i++){
            tv1[i] = GetCardValue(t1[i]);
        }
        ordervalue(tv1, 7);
        arr1[0] = tv1[2];
        arr1[1] = tv1[3];
        arr1[2] = tv1[4];
        arr1[3] = tv1[5];
        arr1[4] = tv1[6];
    }
    else if(n1 == 6){
        j = 0;
        for(i = 0; i < 7; i++){
            if(s1 == GetCardSuit(t1[i])){
                tv1[j] = GetCardValue(t1[i]);
                j++;
            }
            
        }
        ordervalue(tv1, 7);
        arr1[0] = tv1[2];
        arr1[1] = tv1[3];
        arr1[2] = tv1[4];
        arr1[3] = tv1[5];
        arr1[4] = tv1[6];
    }
    else{
        for(i = 0; i < 5; i++){
            arr1[i] = GetCardValue(t1[b1[i]]);
        }
    }

    if(n2 == 7){
        for(i = 0; i < 7; i++){
            tv2[i] = GetCardValue(t2[i]);
        }
        ordervalue(tv1, 7);
        arr2[0] = tv2[2];
        arr2[1] = tv2[3];
        arr2[2] = tv2[4];
        arr2[3] = tv2[5];
        arr2[4] = tv2[6];
    }
    else if(n2 == 6){
        j = 0;
        for(i = 0; i < 7; i++){
            if(s1 == GetCardSuit(t2[i])){
                tv2[j] = GetCardValue(t2[i]);
                j++;
            }
            
        }
        ordervalue(tv2, 7);
        arr2[0] = tv2[2];
        arr2[1] = tv2[3];
        arr2[2] = tv2[4];
        arr2[3] = tv2[5];
        arr2[4] = tv2[6];
    }
    else{
        for(i = 0; i < 5; i++){
            arr2[i] = GetCardValue(t2[b2[i]]);
        }
    }

    if(arr1[4] > arr2[4]){
        return 1;
    }
    else if(arr1[4] < arr2[4]){
        return 0;
    }
    else{
        if(arr1[3] > arr2[3]){
            return 1;
        }
        else if(arr1[3] < arr2[3]){
            return 0;
        }
        else{
            if(arr1[2] > arr2[2]){
                return 1;
            }
            else if(arr1[2] < arr2[2]){
                return 0;
            }
            else{
                if(arr1[1] > arr2[1]){
                    return 1;
                }
                else if(arr1[1] < arr2[1]){
                    return 0;
                }
                else{
                    if(arr1[0] > arr2[0]){
                        return 1;
                    }
                    else if(arr1[0] < arr2[0]){
                        return 0;
                    }
                    else{
                        return 2;
                    }
                }
            }
        }
    }


}

//Compare the type of two players for Fullhouse, return 1 if player1 has a bigger hand, 0 if player2 has a bigger hand, 2 if they are the same
int Compare7(int player1[2], int player2[2], int board[5]){
    int arr1[5] = {0, 0, 0, 0, 0};
    int arr2[5] = {0, 0, 0, 0, 0};
    int p1[5] = {0, 0, 0, 0, 0};
    int p2[5] = {0, 0, 0, 0, 0};
    int c1[7] = {player1[0], player1[1], board[0], board[1], board[2], board[3], board[4]};
    int c2[7] = {player2[0], player2[1], board[0], board[1], board[2], board[3], board[4]};
    int san1; //the part of three of a kind
    int san2;
    int er1;// the part of pair
    int er2;
    int i;

    GetBigPosition(player1, board, p1);
    GetBigPosition(player2, board, p2);

    for(i = 0; i < 5; i++){
        arr1[i] = GetCardValue(c1[p1[i]]);
    }
    
    for(i = 0; i < 5; i++){
        arr2[i] = GetCardValue(c2[p2[i]]);
    }

    ordervalue(arr1, 5);
    ordervalue(arr2, 5);

    if((arr1[0] == arr1[1]) & (arr1[1] == arr1[2])){ //case AAABB
        san1 = arr1[0];
        er1 = arr1[4];
    }
    else{ //case AABBB
        san1 = arr1[2];
        er1 = arr1[0];
    }

    if((arr2[0] == arr2[1]) & (arr2[1] == arr2[2])){ //case AAABB
        san2 = arr2[0];
        er2 = arr2[4];
    }
    else{ //case AABBB
        san2 = arr2[2];
        er2 = arr2[0];
    }

    if(san1 > san2){
        return 1;
    }
    else if(san1 < san2){
        return 0;
    }
    else{
        if(er1 > er2){
            return 1;
        }
        else if(er1 < er2){
            return 0;
        }
        else{
            return 2;
        }
    }


}

//Compare the type of two players for Quads, return 1 if player1 has a bigger hand, 0 if player2 has a bigger hand, 2 if they are the same
int Compare8(int player1[2], int player2[2], int board[5]){
    int arr1[5] = {0, 0, 0, 0, 0};
    int arr2[5] = {0, 0, 0, 0, 0};
    int f1; //the part of four same card
    int f2;
    int r1; //the rest one card
    int r2;
    int c1[7] = {player1[0], player1[1], board[0], board[1], board[2], board[3], board[4]};
    int c2[7] = {player2[0], player2[1], board[0], board[1], board[2], board[3], board[4]};
    int arr3[7] = {0, 0, 0, 0, 0, 0, 0};
    int arr4[7] = {0, 0, 0, 0, 0, 0, 0};
    int i;

    for(i = 0; i < 7; i++){
        arr3[i] = GetCardValue(c1[i]);
        arr4[i] = GetCardValue(c2[i]);
    }

    ordervalue(arr3, 7);
    ordervalue(arr4, 7);

    GetBigPosition(player1, board, arr1);
    GetBigPosition(player2, board, arr2);

    if((arr1[0] == arr1[1]) & (arr1[1] == arr1[2]) & (arr1[2] == arr1[3])) {
        f1 = arr1[0];
    }
    else{
        f1 = arr1[1];
    }

    if((arr2[0] == arr2[1]) & (arr2[1] == arr2[2]) & (arr2[2] == arr2[3])) {
        f2 = arr2[0];
    }
    else{
        f2 = arr2[1];
    }

    if(arr3[6] == f1){
        r1 = arr3[2];
    }
    else{
        r1 = arr3[6];
    }

    if(arr4[6] == f2){
        r2 = arr4[2];
    }
    else{
        r2 = arr4[6];
    }

    if(f1 > f2){
        return 1;
    }
    else if(f1 < f2){
        return 0;
    }
    else{
        if(r1 > r2){
            return 1;
        }
        else if(r1 < r2){
            return 0;
        }
        else{
            return 2;
        }
    }
}

//Compare the type of two players for Straightflush, return 1 if player1 has a bigger hand, 0 if player2 has a bigger hand, 2 if they are the same
int Compare9(int player1[2], int player2[2], int board[5]){
    int arr1[5] = {0, 0, 0, 0, 0};
    int arr2[5] = {0, 0, 0, 0, 0};
    int p1[5] = {0, 0, 0, 0, 0};
    int p2[5] = {0, 0, 0, 0, 0};
    int c1[7] = {player1[0], player1[1], board[0], board[1], board[2], board[3], board[4]};
    int c2[7] = {player2[0], player2[1], board[0], board[1], board[2], board[3], board[4]};
    int i;

    GetBigPosition(player1, board, p1);
    GetBigPosition(player2, board, p2);

    for(i = 0; i < 5; i++){
        arr1[i] = GetCardValue(c1[p1[i]]);
    }
    
    for(i = 0; i < 5; i++){
        arr2[i] = GetCardValue(c2[p2[i]]);
    }

    ordervalue(arr1, 5);
    ordervalue(arr2, 5);
    

    if(arr1[0] > arr2[0]){
        return 1;
    }
    else if(arr1[0] < arr2[0]){
        return 0;
    }
    else{
        return 2;
    }
}
