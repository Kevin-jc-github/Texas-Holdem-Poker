/* server2.c: simple interactive TCP/IP server program
 * based on: http://www.linuxhowtos.org/data/6/server.c
 * extended by Rainer Doemer, 2/11/15
 * extended by team 10
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netinet/in.h>
#include <netdb.h>
#include "Cards.h"
#include "IO.h"
#include <time.h>

/* #define DEBUG */	/* be very verbose */

void FatalError(const char *Program, const char *ErrorMsg)
{
    fputs(Program, stderr);
    fputs(": ", stderr);
    perror(ErrorMsg);
    fputs(Program, stderr);
    fputs(": Exiting!", stderr);
    exit(20);
} /* end of FatalError */

int main(int argc, char *argv[])
{
	char command[20]; /* store the commend from the message */
	char amount[20]; /* store the amount from the message */
	int am; /*To store the int amount of the Raise*/
	int action;
	int pot = 0; /* To store the total pot of the game*/
	int arr1[2] = {0,0};/* To store the hands that plyaer 1 has*/
	char strcomma[] = ",";/* To store the comma*/
	char str12[10];/* To store the second card of player*/
	char board2[10]; /* To store the second card of the board */
	char board3[10]; /* To store the Third card of the board */
	char potstr[10]; /* To store the pot with string form */
	int cards[52];/* To store card deck*/
	int board[5] = {0,0,0,0,0}; /*To store the cards on the board */
	int x;
	int i = 0;
    int l, n;
    int ServSocketFD,	/* socket file descriptor for service */
	DataSocketFD,	/* socket file descriptor for data */
	PortNo;		/* port number */
    socklen_t ClientLen;
    struct sockaddr_in
	ServerAddress,	/* server address (this host) */
	ClientAddress;	/* client address we connect with */
    char RecvBuf[256];	/* message buffer for receiving a message */
    char SendBuf[256];	/* message buffer for sending a response */
    int Exit = 0,
	Shutdown = 0;

    printf("%s: Starting...\n", argv[0]);
    if (argc < 2)
    {   fprintf(stderr, "Usage: %s port\n", argv[0]);
	exit(10);
    }
    PortNo = atoi(argv[1]);	/* get the port number */
#ifdef DEBUG
    printf("%s: Using port %d...\n", argv[0], PortNo);
#endif
    if (PortNo <= 2000)
    {   fprintf(stderr, "%s: invalid port number %d, should be greater 2000\n",
		argv[0], PortNo);
        exit(10);
    }
#ifdef DEBUG
    printf("%s: Creating a socket to serve clients...\n", argv[0]);
#endif
    ServSocketFD = socket(AF_INET, SOCK_STREAM, 0);
    if (ServSocketFD < 0)
    {   FatalError(argv[0], "service socket creation failed");
    }
#ifdef DEBUG
    printf("%s: Preparing the server address...\n", argv[0]);
#endif
    memset(&ServerAddress, 0, sizeof(ServerAddress));
    ServerAddress.sin_family = AF_INET;
    ServerAddress.sin_port = htons(PortNo);
    ServerAddress.sin_addr.s_addr = INADDR_ANY;
#ifdef DEBUG
    printf("%s: Assigning the server name to the socket...\n", argv[0]);
#endif
    if (bind(ServSocketFD, (struct sockaddr*)&ServerAddress,
		sizeof(ServerAddress)) < 0)
    {   FatalError(argv[0], "binding the server to a socket failed");
    }
    printf("%s: Listening on port %d...\n", argv[0], PortNo);
    if (listen(ServSocketFD, 6) < 0)	/* max 6 clients in backlog */
    {   FatalError(argv[0], "listening on socket failed");
    }

    do{ Shutdown = 0;
	ClientLen = sizeof(ClientAddress);
	DataSocketFD = accept(ServSocketFD, (struct sockaddr*)&ClientAddress,
		&ClientLen);
	if (DataSocketFD < 0)
	{   FatalError(argv[0], "data socket creation (accept) failed");
	}
	printf("%s: Accepted connection from client.\n", argv[0]);
#ifdef DEBUG
	printf("%s: Client address:port = %u:%hu.\n", argv[0],
			ClientAddress.sin_addr.s_addr, ntohs(ClientAddress.sin_port));
#endif
	do{ Exit = 0;
	    n = read(DataSocketFD, RecvBuf, sizeof(RecvBuf)-1);
	    if (n < 0) 
	    {   FatalError(argv[0], "reading from data socket failed");
	    }
	       RecvBuf[n] = 0;
	    printf("%s: The player wanted to buy in this amount of chip: %s\n", argv[0], RecvBuf);
	    
	    /* add the function to record the user's balance */
	    
	    if (0 == strcmp(RecvBuf, "exit"))
	    {   Exit = 1;
#ifdef DEBUG
		printf("%s: Received 'exit' from client.\n", argv[0]);
#endif
		strncpy(SendBuf, "exit the server", sizeof(SendBuf)-1);
		SendBuf[sizeof(SendBuf)-1] = 0;
	    }
	    else if (0 == strcmp(RecvBuf, "shutdown"))
	    {   Shutdown = 1;
#ifdef DEBUG
		printf("%s: Received 'shutdown' message from client.\n", argv[0]);
#endif
		strncpy(SendBuf, "server shutdown", sizeof(SendBuf)-1);
		SendBuf[sizeof(SendBuf)-1] = 0;
	    }
	    else
	    {   
	        creatcards(cards); /* To create the card deck with randomly 52 cards*/
		    /*function to deal card*/
		    x = rand()%52 + 1;/* give a random index so that we can get a random card from the deck of the cards*/
    re1:    if(cards[x] == 0){ /* if the elements choosed is zero, then it menas it is null in the cardslist, we need a new index*/
            x = rand()%52 + 1;
            goto re1;
            }
		    Takecards(cards,x); /* Deal the card to the player*/
		    StoreCards(arr1,cards[x]);
		    Takecards(cards,x); /* Deal the card to the player*/
		    StoreCards(arr1,cards[x]);
		    /* then, send the card to the client */
		    itoa(arr1[0],SendBuf,10); /* To store the first card of the player into string text*/
		    itoa(arr1[1],str12,10);
		    strcat(SendBuf,strcomma);
		    strcat(SendBuf,str12);
		    l = strlen(SendBuf);
		    printf("Successful sending preflop cards to the player\n");
		    n = write(DataSocketFD, SendBuf, l);
		    if (n < 0)
		    {   FatalError(argv[0], "writing to data socket failed");
		    }
		    
	    }
	    
	    /* response to client's message flop round*/
	    n = read(DataSocketFD, RecvBuf, sizeof(RecvBuf)-1);
	    if (n < 0) 
	    {   FatalError(argv[0], "reading from data socket failed");
	    }
	    RecvBuf[n] = 0;
	    char * token = strtok(RecvBuf, ","); /* user to seperate the message */
	    while( token != NULL ){
            if (i == 0){
                strcpy(command, token);
            }
            else if(i==1){
            strcpy(amount, token);
            }
            token = strtok(NULL, ",");
            i++;
        }
	    if(strcmp(command, "Raise") == 0){
      	    action = 1;
     	}
	    if(strcmp(command, "Fold") == 0){
      	    action = 2;
     	}
	    if(strcmp(command, "Check") == 0){
      	    action = 3;
    	}
	    if(strcmp(command, "Call") == 0){
      	    action = 4;
     	}
	switch(action){
	    	case 1:
	    	    am = atoi(amount);
	    	    pot = pot + am;
	    	    printf("The player choose Raise to %d\n",am);
	    	    printf("The current pot is %d\n",pot);
	    		break;
	    		
	    	case 2:
	    	    printf("The player choose to fold!\n");
	    		break;
	    	
	    	case 3:
	    		printf("The player choose to check!\n");
	    		break;
	    	
	    	case 4:
	    	    am = atoi(amount);
	    	    pot = pot + am;
	    		printf("The player choose to Call!\n");
	    		printf("The current pot is %d\n",pot);
	    		break;
	    }
	    /* The Flop */
	    Takecards(cards,x); /* Deal the card to the board for flop*/
		Storeboard(board,cards[x]);
		Takecards(cards,x);
		Storeboard(board,cards[x]);
		Takecards(cards,x);
		Storeboard(board,cards[x]);
		PrintBoard(board,pot);
		itoa(board[0],SendBuf,10); /* To store the first card of the board into string text*/
		itoa(board[1],board2,10); /* To store the Second card of the board into string text*/
        itoa(board[2],board3,10); /* To store the Third card of the board into string text*/
        itoa(pot,potstr,10);
        strcat(SendBuf,strcomma);
        strcat(SendBuf,board2);
        strcat(SendBuf,strcomma);
        strcat(SendBuf,board3);
        strcat(SendBuf,strcomma);
        strcat(SendBuf,potstr);
        l = strlen(SendBuf);
		printf("Successfully sending turn card and total pot to the player\n");
		n = write(DataSocketFD, SendBuf, l);
		if (n < 0)
		{   
		    FatalError(argv[0], "writing to data socket failed");
		}

	/* response to client's message turn round*/
	    n = read(DataSocketFD, RecvBuf, sizeof(RecvBuf)-1);
	    if (n < 0) 
	    {   FatalError(argv[0], "reading from data socket failed");
	    }
	    RecvBuf[n] = 0;
	    char * token1 = strtok(RecvBuf, ","); /* user to seperate the message */
	    while( token1 != NULL ){
            if (i == 0){
                strcpy(command, token1);
            }
            else if(i==1){
            strcpy(amount, token1);
            }
            token1 = strtok(NULL, ",");
            i++;
        }
	    if(strcmp(command, "Raise") == 0){
      	    action = 1;
     	}
	    if(strcmp(command, "Fold") == 0){
      	    action = 2;
     	}
	    if(strcmp(command, "Check") == 0){
      	    action = 3;
    	}
	    if(strcmp(command, "Call") == 0){
      	    action = 4;
     	}
	switch(action){
	    	case 1:
	    	    am = atoi(amount);
	    	    pot = pot + am;
	    	    printf("The player choose Raise to %d\n",am);
	    	    printf("The current pot is %d\n",pot);
	    		break;
	    		
	    	case 2:
	    	    printf("The player choose to fold!\n");
	    		break;
	    	
	    	case 3:
	    		printf("The player choose to check!\n");
	    		break;
	    	
	    	case 4:
	    	    am = atoi(amount);
	    	    pot = pot + am;
	    		printf("The player choose to Call!\n");
	    		printf("The current pot is %d\n",pot);
	    		break;
	    }
	    /* The turn */
	    Takecards(cards,x); /* Deal the card to the board for flop*/
	        Storeboard(board,cards[x]);
		PrintBoard(board,pot);
	        itoa(board[3],SendBuf,10); /* To store the 4 card of the board into string text*/
        itoa(pot,potstr,10);
        strcat(SendBuf,strcomma);
        strcat(SendBuf,potstr);
        l = strlen(SendBuf);
		printf("Successfully sending turn card and total pot to the player\n");
		n = write(DataSocketFD, SendBuf, l);
		if (n < 0)
		{   
		    FatalError(argv[0], "writing to data socket failed");
		}
		/* response to client's message turn round*/
	    n = read(DataSocketFD, RecvBuf, sizeof(RecvBuf)-1);
	    if (n < 0) 
	    {   FatalError(argv[0], "reading from data socket failed");
	    }
	    RecvBuf[n] = 0;
	    char * token2 = strtok(RecvBuf, ","); /* user to seperate the message */
	    while( token2 != NULL ){
            if (i == 0){
                strcpy(command, token1);
            }
            else if(i==1){
            strcpy(amount, token2);
            }
            token2 = strtok(NULL, ",");
            i++;
        }
	    if(strcmp(command, "Raise") == 0){
      	    action = 1;
     	}
	    if(strcmp(command, "Fold") == 0){
      	    action = 2;
     	}
	    if(strcmp(command, "Check") == 0){
      	    action = 3;
    	}
	    if(strcmp(command, "Call") == 0){
      	    action = 4;
     	}
	switch(action){
	    	case 1:
	    	    am = atoi(amount);
	    	    pot = pot + am;
	    	    printf("The player choose Raise to %d\n",am);
	    	    printf("The current pot is %d\n",pot);
	    		break;
	    		
	    	case 2:
	    	    printf("The player choose to fold!\n");
	    		break;
	    	
	    	case 3:
	    		printf("The player choose to check!\n");
	    		break;
	    	
	    	case 4:
	    	    am = atoi(amount);
	    	    pot = pot + am;
	    		printf("The player choose to Call!\n");
	    		printf("The current pot is %d\n",pot);
	    		break;
	    }
	    /* The River */
	    Takecards(cards,x); /* Deal the card to the board for flop*/
	        Storeboard(board,cards[x]);
		PrintBoard(board,pot);
	        itoa(board[4],SendBuf,10); /* To store the fifth card of the board into string text*/
       	 itoa(pot,potstr,10);
        	strcat(SendBuf,strcomma);
       	 strcat(SendBuf,potstr);
        	l = strlen(SendBuf);
		printf("Successfully sending turn card and total pot to the player\n");
		n = write(DataSocketFD, SendBuf, l);
		if (n < 0)
		{   
		    FatalError(argv[0], "writing to data socket failed");
		}

	    
	} while(!Exit && !Shutdown);
	printf("%s: Received last message from player, closing data connection.\n", argv[0]);
	close(DataSocketFD);

    } while(!Shutdown);
    printf("%s: Shutting down.\n", argv[0]);
    close(ServSocketFD);
    return 0;
}

/* EOF server2.c */

