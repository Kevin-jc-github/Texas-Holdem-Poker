/* Team 10 */
/* File name: Main.c */
/* Author: Kevin Zhu */
/* Date: 2022/05/05 */

#include <stdio.h>
#include "Cards.h"
#include "IO.h"
#include "Rules.h"


int main()
{
    int player1[2] = {0}; // To store the cards for player 1 that obtain from the card deck
    int player2[2] = {0}; // To store the cards for player 2 that obtain from the card deck
    int player3[2] = {0}; // To store the cards for player 3 that obtain from the card deck
    int player4[2] = {0}; // To store the cards for player 4 that obtain from the card deck
    int player5[2] = {0}; // To store the cards for player 5 that obtain from the card deck
    int board[5] = {0}; // To store what we have on the board
    int Dea; // To store the result that who begin this round as the Dealer
    srand((int)time(0));
    int cards_list[52] = {0};//To store the cards as the card deck
       PrintMenu();
    creatcards(cards_list); // Create a deck of card to play
    Dea = rand()%5 + 1;
    DealtheCard(cards_list,player1,player2,player3,player4,player5,board,Dea);
    return 0;
}




