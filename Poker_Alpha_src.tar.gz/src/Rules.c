/* Team 10 */
/* File name: Rules.c */
/* Author: Kevin Zhu & Pengfei Yan */
/* Creation Date: 2022/05/08 */
/* Modified Date: 2022/05/22 */

#include "Cards.h"
#include "IO.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Get the value of one card
int GetCardValue(int car){
    if(car == 1 || car == 2 || car == 3 || car == 4){ // when the card is 1
        return 14;
    }
    else if(car == 5 || car == 6 || car == 7 || car == 8){ // when the card is 2 
        return 2;
    }
    else if(car == 9 || car == 10 || car == 11 || car == 12){// when the card is 3
        return 3;
    }
    else if(car == 13 || car == 14 || car == 15 || car == 16){// when the card is 4
        return 4;
    }
    else if(car == 17 || car == 18 || car == 19 || car == 20){// when the card is 5
        return 5;
    }
    else if(car == 21 || car == 22 || car == 23 || car == 24){// when the card is 6
        return 6;
    }
    else if(car == 25 || car == 26 || car == 27 || car == 28){// when the card is 7
        return 7;
    }
    else if(car == 29 || car == 30 || car == 31 || car == 32){// when the card is 8
        return 8;
    }
    else if(car == 33 || car == 34 ||  car == 35 || car == 36){// when the card is 9
        return 9;
    }
    else if(car == 37 || car == 38 ||  car == 39 || car == 40){// when the card is 10
        return 10;
    }
    else if(car == 41 || car == 42 ||  car == 43 || car == 44){// when the card is J
        return 11;
    }
    else if(car == 45 || car == 46 ||  car == 47 || car == 48){// when the card is Q
        return 12;
    }
    else if(car == 49 || car == 50 ||  car == 51 || car == 52){// when the card is K
        return 13;
    }
    else{
        return 99;
    }
}

//Get the suit  of one card
int GetCardSuit(int car){
    if(car == 0){
        return 99;
    }
    else if(car%4 == 0){ //when the card is Spades
        return 4;
    }
    else{ //when the card os not Spades
        return car%4;
    }
}

//Get the type of five given cards
int GetCardType(int car[5]){
    int newarr[5];
    int i;
    int s1, s2, s3, s4, s5; //suits of cards
    int v1, v2, v3, v4, v5; //value of cards

    for(i = 0; i < 5; i++){ //create a new array to avoid change the original array
        newarr[i] = car[i];
    }
    OrderCards(newarr);

    s1 = GetCardSuit(newarr[0]);
    s2 = GetCardSuit(newarr[1]);
    s3 = GetCardSuit(newarr[2]);
    s4 = GetCardSuit(newarr[3]);
    s5 = GetCardSuit(newarr[4]);

    v1 = GetCardValue(newarr[0]);
    v2 = GetCardValue(newarr[1]);
    v3 = GetCardValue(newarr[2]);
    v4 = GetCardValue(newarr[3]);
    v5 = GetCardValue(newarr[4]);

    //case of Straightflush
    if((s1 == s2) & (s2 == s3) & (s3 == s4) & (s4 == s5) & (v2 == (v1 + 1)) & (v3 == (v2 + 1)) & (v4 == (v3 + 1)) & (v5 == (v4 + 1))){
        return 9;
    }
    //case of Flush
    else if((s1 == s2) & (s2 == s3) & (s3 == s4) & (s4 == s5)){
        return 6;
    }
    //case of Straight
    else if(((v2 == (v1 + 1)) & (v3 == (v2 + 1)) &( v4 == (v3 + 1) ))& (v5 == (v4 + 1))){
        return 5;
    }
    //case of Quads
    else if( ((v1 == v2) & (v2 == v3) & (v3 == v4)) || ((v2 == v3) & (v3 == v4) & (v4 == v5))){
        return 8;
    }
    //case of Fullhouse
    else if( ((v1 == v2) & (v2 == v3) & (v4 == v5))||((v1 == v2) & (v3 == v4) & (v4 == v5)) ){
        return 7;
    }
    //case of Three of a kind
    else if( ((v1 == v2) & (v2 == v3))||((v2 == v3) & (v3 == v4))||((v3 == v4) & (v4 == v5)) ){
        return 4;
    }
    //case of two pairs
    else if( ((v1 == v2) & (v3 == v4))||((v2 == v3) & (v4 == v5))||((v1 == v2 )& (v4 == v5)) ){
        return 3;
    }
    //case of one pair
    else if((v1 == v2 )|| (v2 == v3) || (v3 == v4 )|| (v4 == v5)){
        return 2;
    }
    //case of highcard
    else{
        return 1;
    }
}

//Get the biggest type of a player
int GetBiggestType(int privatec[2], int publicc[5]){
    int bt = 0; //biggest type
    int t[5]; //temp array to be tested
    int a[7] = {privatec[0], privatec[1], publicc[0], publicc[1], publicc[2], publicc[3], publicc[4]}; //temp array of all 7 cards

    //case 1 that 1st and 2nd cards is not in biggest situation
    t[0] = a[2];
    t[1] = a[3];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 2 that 1st and 3rd cards is not in biggest situation
    t[0] = a[1];
    t[1] = a[3];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 3
    t[0] = a[1];
    t[1] = a[2];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 4
    t[0] = a[1];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 5
    t[0] = a[1];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 6
    t[0] = a[1];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[5];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 7
    t[0] = a[0];
    t[1] = a[3];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 8
    t[0] = a[0];
    t[1] = a[2];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 9
    t[0] = a[0];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 10
    t[0] = a[0];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 11
    t[0] = a[0];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[5];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 12
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 13
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[3];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 14
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 15
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[5];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 16
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 17
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[4];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 18
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[4];
    t[4] = a[5];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 19
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[3];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 20
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[3];
    t[4] = a[5];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    //case 21
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[3];
    t[4] = a[4];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
    }

    return bt;
}

/*
//Get the position(0-7) of the biggest type of a player in an array 
void GetBigPosition(int privatec[2], int publicc[5], int outarr[5]){
    int bt = 0; //biggest type
    int t[5]; //temp array to be tested
    int a[7] = {privatec[0], privatec[1], publicc[0], publicc[1], publicc[2], publicc[3], publicc[4]}; //temp array of all 7 cards

    //case 1 that 1st and 2nd cards is not in biggest situation
    t[0] = a[2];
    t[1] = a[3];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
        outarr = {2, 3, 4, 5, 6};
    }

    //case 2 that 1st and 3rd cards is not in biggest situation
    t[0] = a[1];
    t[1] = a[3];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
        outarr = {1, 3, 4, 5, 6};
    }

    //case 3
    t[0] = a[1];
    t[1] = a[2];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
        outarr = {1, 2, 4, 5, 6};
    }

    //case 4
    t[0] = a[1];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
        outarr = {1, 2, 3, 5, 6};
    }

    //case 5
    t[0] = a[1];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
        outarr = {1, 2, 3, 4, 6};
    }

    //case 6
    t[0] = a[1];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[5];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
        outarr = {1, 2, 3, 4, 5};
    }

    //case 7
    t[0] = a[0];
    t[1] = a[3];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
        outarr = {0, 3, 4, 5, 6};
    }

    //case 8
    t[0] = a[0];
    t[1] = a[2];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
        outarr = {0, 2, 4, 5, 6};
    }

    //case 9
    t[0] = a[0];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
        outarr = {0, 2, 3, 5, 6};
    }

    //case 10
    t[0] = a[0];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
        outarr = {0, 2, 3, 4, 6};
    }

    //case 11
    t[0] = a[0];
    t[1] = a[2];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[5];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
        outarr = {0, 2, 3, 4, 5};
    }

    //case 12
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[4];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
        outarr = {0, 1, 4, 5, 6};
    }

    //case 13
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[3];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
        outarr = {0, 1, 3, 5, 6};
    }

    //case 14
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
        outarr = {0, 1, 3, 4, 6};
    }

    //case 15
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[3];
    t[3] = a[4];
    t[4] = a[5];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
        outarr = {0, 1, 3, 4, 5};
    }

    //case 16
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[5];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
        outarr = {0, 1, 2, 5, 6};
    }

    //case 17
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[4];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
        outarr = {0, 1, 2, 4, 6};
    }

    //case 18
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[4];
    t[4] = a[5];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
        outarr = {0, 1, 2, 4, 5};
    }

    //case 19
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[3];
    t[4] = a[6];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
        outarr = {0, 1, 2, 3, 6};
    }

    //case 20
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[3];
    t[4] = a[5];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
        outarr = {0, 1, 2, 3, 5};
    }

    //case 21
    t[0] = a[0];
    t[1] = a[1];
    t[2] = a[2];
    t[3] = a[3];
    t[4] = a[4];
    if(GetCardType(t) > bt){
        bt = GetCardType(t);
        outarr = {0, 1, 2, 3, 4};
    }
}
*/
