/* Team 10 */
/* File name: Rules.c */
/* Author: Kevin Zhu & Pengfei Yan */
/* Creation Date: 2022/05/05 */
/* Modified Date: 2022/05/22 */

#ifndef CARDS_H
#define CARDS_H

#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <string.h>
#include "IO.h"
#include "Rules.h"

/* Store 52 cards that can be used in the cards game */
/* C means Clubs, D means Diamonds, H means Hearts, S means Spades */
enum Cards{
    CA = 1,DA,HA,SA,
    C2,D2,H2,S2,
    C3,D3,H3,S3,
    C4,D4,H4,S4,
    C5,D5,H5,S5,
    C6,D6,H6,S6,
    C7,D7,H7,S7,
    C8,D8,H8,S8,
    C9,D9,H9,S9,
    C10,D10,H10,S10,
    CJ,DJ,HJ,SJ,
    CQ,DQ,HQ,SQ,
    CK,DK,HK,SK,
}cards;

/* Store 4 suits for cards */
enum Suits{
    Clubs = 1,
    Diamonds = 2,
    Hearts = 3,
    Spades = 4,
}suits;

/* Store the type of 5 cards in the game */
enum Types{
    Highcard = 1,
    Pair = 2,
    Twopair = 3,
    Threeofakind = 4,
    Straight = 5,
    Flush = 6,
    Fullhouse = 7,
    Quads = 8,
    Straightflush = 9,
}types;

//To creat the cards randomly(Shuffle) and store them into an array, so that they are easy to be handled
void creatcards(int cards_list[52]);

// To draw out one card from the deck of the cards and send it to the players or dealer
void dealcards(int cards_list[52],int index);

// To store the cards that the player or dealer obtained from the card deck
void StoreCards(int arr[10], int element);

// To the give order to 5 cards from increasingly
void OrderCards(int arr[5]);

// To deal the card to everybody in one round
int DealtheCard(int card[52],int arr1[2],int arr2[2],int arr3[2],int arr4[2],int arr5[2],int board[5],int dea);
#endif/* CARDS_H */