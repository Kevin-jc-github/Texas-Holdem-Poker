/* Team 10 */
/* File name: Rules.c */
/* Author: Kevin Zhu & Pengfei Yan */
/* Creation Date: 2022/05/08 */
/* Modified Date: 2022/05/22 */

#ifndef Rules_H
#define Rules_H

#include "Cards.h"
#include "IO.h"

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

//Get the value of one card
int GetCardValue(int car);

//Get the suit  of one card
int GetCardSuit(int car);

//Get the type of five given cards
int GetCardType(int car[5]);

//Get the biggest type of a player
int GetBiggestType(int privatec[2], int publicc[5]);

//Get the position(0-7) of the biggest type of a player in an array 
void GetBigPosition(int privatec[2], int publicc[5], int outarr[5]);

#endif /* Rules_H */
