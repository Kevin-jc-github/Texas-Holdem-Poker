/* Team 10 */
/* File name: IO.h */
/* Author: Kevin Zhu */
/* Date: 2022/05/05 */

#ifndef IO_H
#define IO_H

#include <stdio.h>
#include "Cards.h"
#include <stdlib.h>
#include <string.h>
#include "Rules.h"

//Print the Main game menu for the blackJack
void PrintMenu();

// To transfer the value of the card into the text form for the player to look at.
void GetCardText(int cardnumber);

// print the what cards do the players and the dealer have into GetCardText
void Printhands(int arr1[2], int arr2[2],int arr3[2], int arr4[2], int arr5[2],int chips1,int chips2,int chips3,int chips4,int chips5);

// Print out what we have on the board
void PrintBoard(int arr[5],int *pot);

//Player bet and change the current chips the player have
int PlayerBet(int p, int *chips,int *pot,int *Raise, int lastbet,int arr[2]);

//Ask the players how much chips do they want to buy in before starting the game
int AskBuyin(int chips,int p);

// after the player fold, made the hand become zero
void MakeZero(int arr[2]);

#endif /* IO_H */