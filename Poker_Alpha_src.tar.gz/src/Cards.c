/* Team 10 */
/* File name: Rules.c */
/* Author: Kevin Zhu & Pengfei Yan */
/* Creation Date: 2022/05/05 */
/* Modified Date: 2022/05/22 */

#include <stdio.h>
#include <stdlib.h>
#include "Cards.h"
#include <time.h>
#include <string.h>
#include "IO.h"
#include "Rules.h"

//To creat the cards randomly(Shuffle) and store them into an array, so that they are easy to be handled
void creatcards(int cards_list[52]){
    int i = 0;
    int j;
    int r;
	srand((int)time(0));  
	for(int x = 0; x<52;x++){
	    while(i<52)
	    {
		    r=rand() % 52 + 1;  //genereate a random number between 1-52 
		    for(j=i;j>=0;j--)
		    {
			    if(r == cards_list[j])     //Compare with the random number that has been stored in to the array
				break;
	        } 
		    if(j<0)             //if the new one is not the same as we have, then store this one into the cardlist 
		    {
			    cards_list[i]=r;
			    i++;
		    }
	    }
	}
}

// To deal the card from the deck of the cards to the players and dealer 
void dealcards(int cards_list[52],int index){
    int i,b,c;
    b = cards_list[index];
	//delete the "card"(number) from the deck of the cards, because it is been dealed to the players, and also 
	for(i=0;i<52;i++)
    {
        if(cards_list[i] == b)
		{
	        for(c=i;c<52;c++){
	            if(cards_list[c] != 0){
			        cards_list[c]=cards_list[c+1];
			    }
			    else{
			        cards_list[c] = 0;
			    }
	        }
			cards_list[51] = 0;
			i--; 		
		}
    }
    
}


// To store the cards that the player or dealer obtained from the card deck
void StoreCards(int arr[10], int element){
    int i;
    for(i = 0;i < 10;i++){
        if(arr[i] == 0){
            arr[i] = element;
            break;
        }
    }
}

// To deal the card to everybody in one round
int DealtheCard(int card[52],int arr1[2],int arr2[2],int arr3[2],int arr4[2],int arr5[2],int board[5],int dea){
    srand((int)time(0));
    int x;// to record the index of the card that will be deal randomly
    int pot; //Store all the bet that players made
    int Raise = 0; // To check if the last player raise
    int chips1 = 0;
    int chips2 = 0;
    int chips3 = 0;
    int chips4 = 0;
    int chips5 = 0;
    int bet1,bet2,bet3,bet4,bet5 = 0;
    x = rand()%52 + 1;// give a random index so that we can get a random card from the deck of the cards
    /* Ask each players how much they want to buy in */
    chips1 = AskBuyin(chips1,1);
    chips2 = AskBuyin(chips2,2);
    chips3 = AskBuyin(chips3,3);
    chips4 = AskBuyin(chips4,4);
    chips5 = AskBuyin(chips5,5);
    switch(dea){
        case 1:
        printf("Player 1 is the Dealer!\n");
        printf("Player 2 is the Small Blind\n");
        printf("Player 3 is the Big Blind\n");
        printf("\n");
re1:    if(card[x] == 0){ // if the elements choosed is zero, then it menas it is null in the cardslist, we need a new index
            x = rand()%52 + 1;
            goto re1;
        }
        else{
            dealcards(card,x); // deal a card to a player or dealer
            StoreCards(arr2,card[x]);
            dealcards(card,x);
            StoreCards(arr3,card[x]);
            dealcards(card,x);
            StoreCards(arr4,card[x]);
            dealcards(card,x);
            StoreCards(arr5,card[x]);
            dealcards(card,x);
            StoreCards(arr1,card[x]); // Since the player 1 is the dealer, he receive card at last
            dealcards(card,x);
            StoreCards(arr2,card[x]);
            dealcards(card,x);
            StoreCards(arr3,card[x]);
            dealcards(card,x);
            StoreCards(arr4,card[x]);
            dealcards(card,x);
            StoreCards(arr5,card[x]);
            dealcards(card,x);
            StoreCards(arr1,card[x]); // Since the player 1 is the dealer, he receive card at last
            Printhands(arr1,arr2,arr3,arr4,arr5,chips1,chips2,chips3,chips4,chips5);
            /* Players bet preflop */
rera1:      bet4 = PlayerBet(4,&chips4,&pot,&Raise,bet3,arr4);//Player 4 as the cutoff position, he will make the decision at first as the preflop
            bet5 = PlayerBet(5,&chips5,&pot,&Raise,bet4,arr5);
            if(bet5 > bet4){
                Raise = 1;
            }
            bet1 = PlayerBet(1,&chips1,&pot,&Raise,bet5,arr1);
            if(bet1 > bet5){
                Raise = 1;
            }
            bet2 = PlayerBet(2,&chips2,&pot,&Raise,bet1,arr2);
            if(bet2 > bet1){
                Raise = 1;
            }
            bet3 = PlayerBet(3,&chips3,&pot,&Raise,bet3,arr3);
            if(bet3 > bet2){
                Raise = 1;
                goto rera1;
            }
            else{
                bet1 = bet2 = bet3 = bet4 =  bet5 = 0;
                /* Start to deal card to the board(The Flop) */
                dealcards(card,x);
                StoreCards(board,card[x]);
                dealcards(card,x);
                StoreCards(board,card[x]);
                dealcards(card,x);
                StoreCards(board,card[x]);
                PrintBoard(board,&pot);
                /*Player make decision after flop comes out*/
rera11:         bet2 = PlayerBet(2,&chips2,&pot,&Raise,bet1,arr2);//Player 2 as the Small blind position, he will make the decision at first as the preflop
                bet3 = PlayerBet(3,&chips3,&pot,&Raise,bet2,arr3);
                if(bet3 > bet2){
                    Raise = 1;
                }
                bet4 = PlayerBet(4,&chips4,&pot,&Raise,bet3,arr4);
                if(bet4 > bet3){
                    Raise = 1;
                }
                bet5 = PlayerBet(5,&chips5,&pot,&Raise,bet4,arr5);
                if(bet5 > bet4){
                    Raise = 1;
                }
                bet1 = PlayerBet(1,&chips3,&pot,&Raise,bet5,arr1);
                if(bet1 > bet5){
                    Raise = 1;
                    goto rera11;
                }
                else{
                    bet1 = bet2 = bet3 = bet4 =  bet5 = 0;
                    /* Deal the card for turn */
                    dealcards(card,x);
                    StoreCards(board,card[x]);
                    PrintBoard(board,&pot);
                    /* Players make decisions after the turn comes out */
rera12:             bet2 = PlayerBet(2,&chips2,&pot,&Raise,bet1,arr2);//Player 2 as the Small blind position, he will make the decision at first as the preflop
                    bet3 = PlayerBet(3,&chips3,&pot,&Raise,bet2,arr3);
                    if(bet3 > bet2){
                        Raise = 1;
                    }
                    bet4 = PlayerBet(4,&chips4,&pot,&Raise,bet3,arr4);
                    if(bet4 > bet3){
                        Raise = 1;
                    }
                    bet5 = PlayerBet(5,&chips5,&pot,&Raise,bet4,arr5);
                    if(bet5 > bet4){
                        Raise = 1;
                    }
                    bet1 = PlayerBet(1,&chips3,&pot,&Raise,bet5,arr1);
                    if(bet1 > bet5){
                        Raise = 1;
                        goto rera12;
                    }
                    else{
                        bet1 = bet2 = bet3 = bet4 =  bet5 = 0;
                        /* Deal the card for river */
                        dealcards(card,x);
                        StoreCards(board,card[x]);
                        PrintBoard(board,&pot);
                        /* Players make decisions after river comes out */
rera13:                 bet2 = PlayerBet(2,&chips2,&pot,&Raise,bet1,arr2);//Player 2 as the Small blind position, he will make the decision at first as the preflop
                        bet3 = PlayerBet(3,&chips3,&pot,&Raise,bet2,arr3);
                        if(bet3 > bet2){
                            Raise = 1;
                        }
                        bet4 = PlayerBet(4,&chips4,&pot,&Raise,bet3,arr4);
                        if(bet4 > bet3){
                            Raise = 1;
                        }
                        bet5 = PlayerBet(5,&chips5,&pot,&Raise,bet4,arr5);
                        if(bet5 > bet4){
                            Raise = 1;
                        }
                        bet1 = PlayerBet(1,&chips3,&pot,&Raise,bet5,arr1);
                        if(bet1 > bet5){
                            Raise = 1;
                            goto rera13;
                        }
                        else{
                            break;
                        }
                    }
                }
            }
            printf("\n");
            break;   
        }
        /* when player 2 is dealer */
        case 2:
        printf("Player 2 is the Dealer!\n");
        printf("Player 3 is the Small Blind\n");
        printf("Player 4 is the Big Blind\n");
        printf("\n");
re2:    if(card[x] == 0){ // if the elements choosed is zero, then it menas it is null in the cardslist, we need a new index
            x = rand()%52 + 1;
            goto re2;
        }
        else{
            dealcards(card,x); // deal a card to a player or dealer
            StoreCards(arr2,card[x]);
            dealcards(card,x);
            StoreCards(arr3,card[x]);
            dealcards(card,x);
            StoreCards(arr4,card[x]);
            dealcards(card,x);
            StoreCards(arr5,card[x]);
            dealcards(card,x);
            StoreCards(arr1,card[x]);
            dealcards(card,x);
            StoreCards(arr2,card[x]);
            dealcards(card,x);
            StoreCards(arr3,card[x]);
            dealcards(card,x);
            StoreCards(arr4,card[x]);
            dealcards(card,x);
            StoreCards(arr5,card[x]);
            dealcards(card,x);
            StoreCards(arr1,card[x]); 
            Printhands(arr1,arr2,arr3,arr4,arr5,chips1,chips2,chips3,chips4,chips5);
            /* Players bet preflop */
rera2:      bet5 = PlayerBet(5,&chips5,&pot,&Raise,bet4,arr5);//Player 5 as the cutoff position, he will make the decision at first as the preflop
            bet1 = PlayerBet(1,&chips1,&pot,&Raise,bet5,arr1);
            if(bet1 > bet5){
                Raise = 1;
            }
            bet2 = PlayerBet(2,&chips2,&pot,&Raise,bet1,arr2);
            if(bet2 > bet1){
                Raise = 1;
            }
            bet3 = PlayerBet(3,&chips3,&pot,&Raise,bet2,arr3);
            if(bet3 > bet2){
                Raise = 1;
            }
            bet4 = PlayerBet(4,&chips4,&pot,&Raise,bet3,arr4);
            if(bet4 > bet3){
                Raise = 1;
                goto rera2;
            }
            else{
                bet1 = bet2 = bet3 = bet4 =  bet5 = 0;
                /* Start to deal card to the board(The Flop) */
                dealcards(card,x);
                StoreCards(board,card[x]);
                dealcards(card,x);
                StoreCards(board,card[x]);
                dealcards(card,x);
                StoreCards(board,card[x]);
                PrintBoard(board,&pot);
                /*Player make decision after flop comes out*/
rera21:         bet3 = PlayerBet(3,&chips3,&pot,&Raise,bet2,arr3);//Player 3 as the Small blind position, he will make the decision at first as the preflop
                bet4 = PlayerBet(4,&chips4,&pot,&Raise,bet3,arr4);
                if(bet4 > bet3){
                    Raise = 1;
                }
                bet5 = PlayerBet(5,&chips5,&pot,&Raise,bet4,arr5);
                if(bet5 > bet4){
                    Raise = 1;
                }
                bet1 = PlayerBet(1,&chips1,&pot,&Raise,bet5,arr1);
                if(bet1 > bet5){
                    Raise = 1;
                }
                bet2 = PlayerBet(2,&chips2,&pot,&Raise,bet1,arr2);
                if(bet2 > bet1){
                    Raise = 1;
                    goto rera21;
                }
                else{
                    bet1 = bet2 = bet3 = bet4 =  bet5 = 0;
                    /* Deal the card for turn */
                    dealcards(card,x);
                    StoreCards(board,card[x]);
                    PrintBoard(board,&pot);
                    /* Players make decisions after the turn comes out */
rera22:         bet3 = PlayerBet(3,&chips3,&pot,&Raise,bet2,arr3);//Player 3 as the Small blind position, he will make the decision at first as the preflop
                bet4 = PlayerBet(4,&chips4,&pot,&Raise,bet3,arr4);
                if(bet4 > bet3){
                    Raise = 1;
                }
                bet5 = PlayerBet(5,&chips5,&pot,&Raise,bet4,arr5);
                if(bet5 > bet4){
                    Raise = 1;
                }
                bet1 = PlayerBet(1,&chips1,&pot,&Raise,bet5,arr1);
                if(bet1 > bet5){
                    Raise = 1;
                }   
                bet2 = PlayerBet(2,&chips2,&pot,&Raise,bet1,arr2);
                if(bet2 > bet1){
                    Raise = 1;
                    goto rera22;
                }
                else{
                    bet1 = bet2 = bet3 = bet4 =  bet5 = 0;
                    /* Deal the card for river */
                    dealcards(card,x);
                    StoreCards(board,card[x]);
                    PrintBoard(board,&pot);
                    /* Players make decisions after river comes out */
rera23:             bet3 = PlayerBet(3,&chips3,&pot,&Raise,bet2,arr3);//Player 3 as the Small blind position, he will make the decision at first as the preflop
                    bet4 = PlayerBet(4,&chips4,&pot,&Raise,bet3,arr4);
                    if(bet4 > bet3){
                        Raise = 1;
                    }
                bet5 = PlayerBet(5,&chips5,&pot,&Raise,bet4,arr5);
                if(bet5 > bet4){
                    Raise = 1;
                }
                bet1 = PlayerBet(1,&chips1,&pot,&Raise,bet5,arr1);
                if(bet1 > bet5){
                    Raise = 1;
                }
                bet2 = PlayerBet(2,&chips2,&pot,&Raise,bet1,arr2);
                if(bet2 > bet1){
                    Raise = 1;
                    goto rera23;
                }
                else{
                    break;
                }
                    }
                }
            }
            printf("\n");
            break;   
        }
        /* When the player 3 is the dealer */
        case 3:
        printf("Player 3 is the Dealer!\n");
        printf("Player 4 is the Small Blind\n");
        printf("Player 5 is the Big Blind\n");
        printf("\n");
re3:    if(card[x] == 0){ // if the elements choosed is zero, then it menas it is null in the cardslist, we need a new index
            x = rand()%52 + 1;
            goto re3;
        }
        else{
            dealcards(card,x); // deal a card to a player or dealer
            StoreCards(arr2,card[x]);
            dealcards(card,x);
            StoreCards(arr3,card[x]);
            dealcards(card,x);
            StoreCards(arr4,card[x]);
            dealcards(card,x);
            StoreCards(arr5,card[x]);
            dealcards(card,x);
            StoreCards(arr1,card[x]); 
            dealcards(card,x);
            StoreCards(arr2,card[x]);
            dealcards(card,x);
            StoreCards(arr3,card[x]);
            dealcards(card,x);
            StoreCards(arr4,card[x]);
            dealcards(card,x);
            StoreCards(arr5,card[x]);
            dealcards(card,x);
            StoreCards(arr1,card[x]); 
            Printhands(arr1,arr2,arr3,arr4,arr5,chips1,chips2,chips3,chips4,chips5);
            /* Players bet preflop */
rera3:      bet1 = PlayerBet(1,&chips1,&pot,&Raise,bet5,arr1);//Player 1 as the cutoff position, he will make the decision at first as the preflop
            bet2 = PlayerBet(2,&chips2,&pot,&Raise,bet1,arr2);
            if(bet2 > bet1){
                Raise = 1;
            }
            bet3 = PlayerBet(3,&chips3,&pot,&Raise,bet2,arr3);
            if(bet3 > bet2){
                Raise = 1;
            }
            bet4 = PlayerBet(4,&chips4,&pot,&Raise,bet3,arr4);
            if(bet4 > bet3){
                Raise = 1;
            }
            bet5 = PlayerBet(5,&chips5,&pot,&Raise,bet4,arr5);
            if(bet5 > bet4){
                Raise = 1;
                goto rera3;
            }
            else{
                bet1 = bet2 = bet3 = bet4 =  bet5 = 0;
                /* Start to deal card to the board(The Flop) */
                dealcards(card,x);
                StoreCards(board,card[x]);
                dealcards(card,x);
                StoreCards(board,card[x]);
                dealcards(card,x);
                StoreCards(board,card[x]);
                PrintBoard(board,&pot);
                /*Player make decision after flop comes out*/
rera31:         bet4 = PlayerBet(4,&chips4,&pot,&Raise,bet3,arr4);//Player 4 as the Small blind position, he will make the decision at first as the preflop
                bet5 = PlayerBet(5,&chips5,&pot,&Raise,bet4,arr5);
                if(bet5 > bet4){
                    Raise = 1;
                }
                bet1 = PlayerBet(1,&chips1,&pot,&Raise,bet5,arr1);
                if(bet1 > bet5){
                    Raise = 1;
                }
                bet2 = PlayerBet(2,&chips2,&pot,&Raise,bet1,arr2);
                if(bet2 > bet1){
                    Raise = 1;
                }
                bet3 = PlayerBet(3,&chips3,&pot,&Raise,bet2,arr3);
                if(bet3 > bet2){
                    Raise = 1;
                    goto rera31;
                }
                else{
                    bet1 = bet2 = bet3 = bet4 =  bet5 = 0;
                    /* Deal the card for turn */
                    dealcards(card,x);
                    StoreCards(board,card[x]);
                    PrintBoard(board,&pot);
                    /* Players make decisions after the turn comes out */
rera32:             bet4 = PlayerBet(4,&chips4,&pot,&Raise,bet3,arr4);//Player 4 as the Small blind position, he will make the decision at first as the preflop
                    bet5 = PlayerBet(5,&chips5,&pot,&Raise,bet4,arr5);
                    if(bet5 > bet4){
                        Raise = 1;
                    }
                    bet1 = PlayerBet(1,&chips1,&pot,&Raise,bet5,arr1);
                    if(bet1 > bet5){
                        Raise = 1;
                    }
                    bet2 = PlayerBet(2,&chips2,&pot,&Raise,bet1,arr2);
                    if(bet2 > bet1){
                        Raise = 1;
                    }
                    bet3 = PlayerBet(3,&chips3,&pot,&Raise,bet2,arr3);
                    if(bet3 > bet2){
                        Raise = 1;
                        goto rera32;
                    }
                    else{
                        bet1 = bet2 = bet3 = bet4 =  bet5 = 0;
                        /* Deal the card for river */
                        dealcards(card,x);
                        StoreCards(board,card[x]);
                        PrintBoard(board,&pot);
                        /* Players make decisions after river comes out */
rera33:                 bet4 = PlayerBet(4,&chips4,&pot,&Raise,bet3,arr4);//Player 4 as the Small blind position, he will make the decision at first as the preflop
                        bet5 = PlayerBet(5,&chips5,&pot,&Raise,bet4,arr5);
                        if(bet5 > bet4){
                            Raise = 1;
                        }
                        bet1 = PlayerBet(1,&chips1,&pot,&Raise,bet5,arr1);
                        if(bet1 > bet5){
                            Raise = 1;
                        }
                        bet2 = PlayerBet(2,&chips2,&pot,&Raise,bet1,arr2);
                        if(bet2 > bet1){
                            Raise = 1;
                        }
                        bet3 = PlayerBet(3,&chips3,&pot,&Raise,bet2,arr3);
                        if(bet3 > bet2){
                            Raise = 1;
                            goto rera33;
                        }
                        else{
                            printf("Complete!\n");
                            break;
                        }
                    }
                }
            }
            printf("\n");
            break;   
        }
        /* When the player 4 is the dealer */
        case 4:
        printf("Player 4 is the Dealer!\n");
        printf("Player 5 is the Small Blind\n");
        printf("Player 1 is the Big Blind\n");
        printf("\n");
re4:    if(card[x] == 0){ // if the elements choosed is zero, then it menas it is null in the cardslist, we need a new index
            x = rand()%52 + 1;
            goto re4;
        }
        else{
            dealcards(card,x); // deal a card to a player or dealer
            StoreCards(arr2,card[x]);
            dealcards(card,x);
            StoreCards(arr3,card[x]);
            dealcards(card,x);
            StoreCards(arr4,card[x]);
            dealcards(card,x);
            StoreCards(arr5,card[x]);
            dealcards(card,x);
            StoreCards(arr1,card[x]); 
            dealcards(card,x);
            StoreCards(arr2,card[x]);
            dealcards(card,x);
            StoreCards(arr3,card[x]);
            dealcards(card,x);
            StoreCards(arr4,card[x]);
            dealcards(card,x);
            StoreCards(arr5,card[x]);
            dealcards(card,x);
            StoreCards(arr1,card[x]); 
            Printhands(arr1,arr2,arr3,arr4,arr5,chips1,chips2,chips3,chips4,chips5);
            /* Players bet preflop */
rera4:      bet2 = PlayerBet(2,&chips2,&pot,&Raise,bet1,arr2);//Player 2 as the cutoff position, he will make the decision at first as the preflop
            bet3 = PlayerBet(3,&chips3,&pot,&Raise,bet2,arr3);
            if(bet3 > bet2){
                Raise = 1;
            }
            bet4 = PlayerBet(4,&chips4,&pot,&Raise,bet3,arr4);
            if(bet4 > bet3){
                Raise = 1;
            }
            bet5 = PlayerBet(5,&chips5,&pot,&Raise,bet4,arr5);
            if(bet5 > bet4){
                Raise = 1;
            }
            bet1 = PlayerBet(1,&chips1,&pot,&Raise,bet5,arr1);
            if(bet1 > bet5){
                Raise = 1;
                goto rera4;
            }
            else{
                bet1 = bet2 = bet3 = bet4 =  bet5 = 0;
                /* Start to deal card to the board(The Flop) */
                dealcards(card,x);
                StoreCards(board,card[x]);
                dealcards(card,x);
                StoreCards(board,card[x]);
                dealcards(card,x);
                StoreCards(board,card[x]);
                PrintBoard(board,&pot);
                /*Player make decision after flop comes out*/
rera41:         bet5 = PlayerBet(5,&chips5,&pot,&Raise,bet4,arr5);//Player 5 as the Small blind position, he will make the decision at first as the preflop
                bet1 = PlayerBet(1,&chips1,&pot,&Raise,bet5,arr1);
                if(bet1 > bet5){
                    Raise = 1;
                }
                bet2 = PlayerBet(2,&chips2,&pot,&Raise,bet1,arr2);
                if(bet2 > bet1){
                    Raise = 1;
                }
                bet3 = PlayerBet(3,&chips3,&pot,&Raise,bet2,arr3);
                if(bet3 > bet2){
                    Raise = 1;
                }
                bet4 = PlayerBet(4,&chips4,&pot,&Raise,bet3,arr4);
                if(bet4 > bet3){
                    Raise = 1;
                    goto rera41;
                }
                else{
                    bet1 = bet2 = bet3 = bet4 =  bet5 = 0;
                    /* Deal the card for turn */
                    dealcards(card,x);
                    StoreCards(board,card[x]);
                    PrintBoard(board,&pot);
                    /* Players make decisions after the turn comes out */
rera42:             bet5 = PlayerBet(5,&chips5,&pot,&Raise,bet4,arr5);//Player 5 as the Small blind position, he will make the decision at first as the preflop
                    bet1 = PlayerBet(1,&chips1,&pot,&Raise,bet5,arr1);
                    if(bet1 > bet5){
                        Raise = 1;
                    }
                    bet2 = PlayerBet(2,&chips2,&pot,&Raise,bet1,arr2);
                    if(bet2 > bet1){
                        Raise = 1;
                    }
                    bet3 = PlayerBet(3,&chips3,&pot,&Raise,bet2,arr3);
                    if(bet3 > bet2){
                        Raise = 1;
                    }
                    bet4 = PlayerBet(4,&chips4,&pot,&Raise,bet3,arr4);
                    if(bet4 > bet3){
                        Raise = 1;
                        goto rera42;
                    }
                    else{
                        bet1 = bet2 = bet3 = bet4 =  bet5 = 0;
                        /* Deal the card for river */
                        dealcards(card,x);
                        StoreCards(board,card[x]);
                        PrintBoard(board,&pot);
                        /* Players make decisions after river comes out */
rera43:                 bet5 = PlayerBet(5,&chips5,&pot,&Raise,bet4,arr5);//Player 5 as the Small blind position, he will make the decision at first as the preflop
                        bet1 = PlayerBet(1,&chips1,&pot,&Raise,bet5,arr1);
                        if(bet1 > bet5){
                            Raise = 1;
                        }
                        bet2 = PlayerBet(2,&chips2,&pot,&Raise,bet1,arr2);
                        if(bet2 > bet1){
                            Raise = 1;
                        }
                        bet3 = PlayerBet(3,&chips3,&pot,&Raise,bet2,arr3);
                        if(bet3 > bet2){
                            Raise = 1;
                        }
                        bet4 = PlayerBet(4,&chips4,&pot,&Raise,bet3,arr4);
                        if(bet4 > bet3){
                            Raise = 1;
                            goto rera43;
                        }
                        else{
                            printf("Complete!\n");
                            break;
                        }
                    }
                }
            }
            printf("\n");
            break;   
        }
        /*When the player 5 is the dealer */
        case 5:
        printf("Player 5 is the Dealer!\n");
        printf("Player 1 is the Small Blind\n");
        printf("Player 2 is the Big Blind\n");
        printf("\n");
re5:    if(card[x] == 0){ // if the elements choosed is zero, then it menas it is null in the cardslist, we need a new index
            x = rand()%52 + 1;
            goto re5;
        }
        else{
            dealcards(card,x); // deal a card to a player or dealer
            StoreCards(arr2,card[x]);
            dealcards(card,x);
            StoreCards(arr3,card[x]);
            dealcards(card,x);
            StoreCards(arr4,card[x]);
            dealcards(card,x);
            StoreCards(arr5,card[x]);
            dealcards(card,x);
            StoreCards(arr1,card[x]); 
            dealcards(card,x);
            StoreCards(arr2,card[x]);
            dealcards(card,x);
            StoreCards(arr3,card[x]);
            dealcards(card,x);
            StoreCards(arr4,card[x]);
            dealcards(card,x);
            StoreCards(arr5,card[x]);
            dealcards(card,x);
            StoreCards(arr1,card[x]); 
            Printhands(arr1,arr2,arr3,arr4,arr5,chips1,chips2,chips3,chips4,chips5);
            /* Players bet preflop */
rera5:      bet3 = PlayerBet(3,&chips3,&pot,&Raise,bet2,arr3);//Player 3 as the cutoff position, he will make the decision at first as the preflop
            bet4 = PlayerBet(4,&chips4,&pot,&Raise,bet3,arr4);
            if(bet4 > bet3){
                Raise = 1;
            }
            bet5 = PlayerBet(5,&chips5,&pot,&Raise,bet4,arr5);
            if(bet5 > bet4){
                Raise = 1;
            }
            bet1 = PlayerBet(1,&chips1,&pot,&Raise,bet5,arr1);
            if(bet1 > bet5){
                Raise = 1;
            }
            bet2 = PlayerBet(2,&chips2,&pot,&Raise,bet1,arr2);
            if(bet2 > bet1){
                Raise = 1;
                goto rera5;
            }
            else{
                bet1 = bet2 = bet3 = bet4 =  bet5 = 0;
                /* Start to deal card to the board(The Flop) */
                dealcards(card,x);
                StoreCards(board,card[x]);
                dealcards(card,x);
                StoreCards(board,card[x]);
                dealcards(card,x);
                StoreCards(board,card[x]);
                PrintBoard(board,&pot);
                /*Player make decision after flop comes out*/
rera51:         bet1 = PlayerBet(1,&chips1,&pot,&Raise,bet5,arr1);//Player 1 as the Small blind position, he will make the decision at first as the preflop
                bet2 = PlayerBet(2,&chips2,&pot,&Raise,bet1,arr2);
                if(bet2 > bet1){
                    Raise = 1;
                }
                bet3 = PlayerBet(3,&chips3,&pot,&Raise,bet2,arr3);
                if(bet3 > bet2){
                    Raise = 1;
                }
                bet4 = PlayerBet(4,&chips4,&pot,&Raise,bet3,arr4);
                if(bet4 > bet3){
                    Raise = 1;
                }
                bet5 = PlayerBet(5,&chips5,&pot,&Raise,bet4,arr5);
                if(bet5 > bet4){
                    Raise = 1;
                    goto rera51;
                }
                else{
                    bet1 = bet2 = bet3 = bet4 =  bet5 = 0;
                    /* Deal the card for turn */
                    dealcards(card,x);
                    StoreCards(board,card[x]);
                    PrintBoard(board,&pot);
                    /* Players make decisions after the turn comes out */
rera52:             bet1 = PlayerBet(1,&chips1,&pot,&Raise,bet5,arr1);//Player 1 as the Small blind position, he will make the decision at first as the preflop
                    bet2 = PlayerBet(2,&chips2,&pot,&Raise,bet1,arr2);
                    if(bet2 > bet1){
                        Raise = 1;
                    }
                    bet3 = PlayerBet(3,&chips3,&pot,&Raise,bet2,arr3);
                    if(bet3 > bet2){
                        Raise = 1;
                    }
                    bet4 = PlayerBet(4,&chips4,&pot,&Raise,bet3,arr4);
                    if(bet4 > bet3){
                        Raise = 1;
                    }
                    bet5 = PlayerBet(5,&chips5,&pot,&Raise,bet4,arr5);
                    if(bet5 > bet4){
                        Raise = 1;
                        goto rera52;
                    }
                    else{
                        bet1 = bet2 = bet3 = bet4 =  bet5 = 0;
                        /* Deal the card for river */
                        dealcards(card,x);
                        StoreCards(board,card[x]);
                        PrintBoard(board,&pot);
                        /* Players make decisions after river comes out */
rera53:                 bet1 = PlayerBet(1,&chips1,&pot,&Raise,bet5,arr1);//Player 1 as the Small blind position, he will make the decision at first as the preflop
                        bet2 = PlayerBet(2,&chips2,&pot,&Raise,bet1,arr2);
                        if(bet2 > bet1){
                            Raise = 1;
                        }
                        bet3 = PlayerBet(3,&chips3,&pot,&Raise,bet2,arr3);
                        if(bet3 > bet2){
                            Raise = 1;
                        }
                        bet4 = PlayerBet(4,&chips4,&pot,&Raise,bet3,arr4);
                        if(bet4 > bet3){
                            Raise = 1;
                        }
                        bet5 = PlayerBet(5,&chips5,&pot,&Raise,bet4,arr5);
                        if(bet5 > bet4){
                            Raise = 1;
                            goto rera53;
                        }
                        else{
                            printf("Complete!\n");
                            break;
                        }
                    }
                }
            }
            printf("\n");
            break;   
        }
        return 1;
    }
}

// To the give order to 5 cards from increasingly
void OrderCards(int arr[5]){
	int newarr[5];
	int i;
	int t;
	
	for(t = 0; t < 5; t++){
		int min = 15;
		int j;
		for(i = 0; i < 5; i++)
		{
			if(GetCardValue(arr[i])<min){ //find a smallest card
				min = GetCardValue(arr[i]);
				j = i;
			}
		}
	newarr[t] = arr[j];
	arr[j] = 0;
	}

	for(i = 0; i < 5; i++){ //change the number in array
		arr[i] = newarr[i];
	}
}